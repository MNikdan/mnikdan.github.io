package ir.rafsanjan.admin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;

import androidx.annotation.Nullable;
import ir.rafsanjan.admin.base.BaseActivity;
import ir.rafsanjan.admin.chat.management.ChatManager;
import ir.rafsanjan.admin.main.TilesActivity;

public class PasswordActivity extends BaseActivity {
    private MaterialDialog mDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.password_activity);

        findViewById(R.id.password_activity_button).setOnClickListener(v -> {
            AdminApplication.PASSWORD = ((EditText) findViewById(R.id.password_activity_edit)).getText().toString();
            tryToGetPhone();
        });
    }

    private void tryToGetPhone() {
        mDialog = new MaterialDialog.Builder(this)
                .progress(true, 100)
                .title("در حال تایید رمز عبور")
                .cancelable(false)
                .show();

        StringRequest request = new StringRequest(
                Request.Method.GET,
                AdminApplication.BASE_URL + "admin/chat/get_admin_phone.php?password=" + AdminApplication.PASSWORD,
                response -> {
                    if (response == null || response.trim().length() != 11)
                        onError();
                    else {
                        ChatManager.phone = response;
                        onSuccess();
                    }
                },
                error -> {
                    error.printStackTrace();
                    onError();
                }
        );
        AdminApplication.volley.add(request);
    }

    private void onError() {
        if (mDialog != null) {
            mDialog.dismiss();
            mDialog = null;
        }

        Toast.makeText(this, "خطا", Toast.LENGTH_SHORT).show();
    }

    private void onSuccess() {
        if (mDialog != null) {
            mDialog.dismiss();
            mDialog = null;
        }

        AdminApplication.app.initChatStuff();
        startActivity(new Intent(this, TilesActivity.class));
    }
}
