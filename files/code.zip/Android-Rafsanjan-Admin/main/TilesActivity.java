package ir.rafsanjan.admin.main;

import android.os.Bundle;

import androidx.annotation.Nullable;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.base.BaseActivity;
import ir.rafsanjan.admin.chat.list.ChatListActivity;
import ir.rafsanjan.admin.edit.activities.loaders.AdadActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.AdvertisementActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.AkkaskhooneActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.CommentActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.KasbokarActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.PesteActivityLoader;
import ir.rafsanjan.admin.list.loaders.AdCatsListLoader;
import ir.rafsanjan.admin.list.loaders.AdvertisementsListLoader;
import ir.rafsanjan.admin.list.loaders.AkkaskhooneListLoader;
import ir.rafsanjan.admin.list.loaders.BlocksListLoader;
import ir.rafsanjan.admin.list.loaders.CommentListLoader;
import ir.rafsanjan.admin.list.loaders.KasbokarCatsListLoader;
import ir.rafsanjan.admin.list.loaders.KasbokarListLoader;
import ir.rafsanjan.admin.list.loaders.MatbooatsListLoader;
import ir.rafsanjan.admin.list.loaders.MessagesListLoader;
import ir.rafsanjan.admin.list.loaders.NewsCatsListLoader;
import ir.rafsanjan.admin.list.loaders.NewsListLoader;
import ir.rafsanjan.admin.list.loaders.SlidersListLoader;
import ir.rafsanjan.admin.list.loaders.UsersListLoader;

public class TilesActivity extends BaseActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tiles_layout);

        setOnClicks();
    }

    private void setOnClicks() {
        findViewById(R.id.news_list_tile).setOnClickListener(v -> new NewsListLoader().startActivity(this));
        findViewById(R.id.chat_tile).setOnClickListener(v -> ChatListActivity.start(this));
        findViewById(R.id.kasbokars_list_tile).setOnClickListener(v -> new KasbokarListLoader().startActivity(this));
        findViewById(R.id.advertisements_list_tile).setOnClickListener(v -> new AdvertisementsListLoader().startActivity(this));
        findViewById(R.id.akkaskhoone_list_tile).setOnClickListener(v -> new AkkaskhooneListLoader().startActivity(this));
        findViewById(R.id.matbooats_list_tile).setOnClickListener(v -> new MatbooatsListLoader().startActivity(this));
        findViewById(R.id.messages_list_tile).setOnClickListener(v -> new MessagesListLoader().startActivity(this));
        findViewById(R.id.comments_list_tile).setOnClickListener(v -> new CommentListLoader().startActivity(this));
        findViewById(R.id.kasbokar_cats_tile).setOnClickListener(v -> new KasbokarCatsListLoader().startActivity(this));
        findViewById(R.id.ad_cats_tile).setOnClickListener(v -> new AdCatsListLoader().startActivity(this));
        findViewById(R.id.sliders_list_tile).setOnClickListener(v -> new SlidersListLoader().startActivity(this));
        findViewById(R.id.blocks_list_tile).setOnClickListener(v -> new BlocksListLoader().startActivity(this));
        findViewById(R.id.adad_tile).setOnClickListener(v -> new AdadActivityLoader().startActivity(this));
        findViewById(R.id.peste_tile).setOnClickListener(v -> new PesteActivityLoader().startActivity(this));
        findViewById(R.id.news_cat_list_tile).setOnClickListener(v -> new NewsCatsListLoader().startActivity(this));
        findViewById(R.id.users_list_tile).setOnClickListener(v -> new UsersListLoader().startActivity(this));

        findViewById(R.id.kasbokars_list_tile).setOnLongClickListener(v -> {
            new KasbokarActivityLoader().startActivity(this, -1);
            return true;
        });
        findViewById(R.id.advertisements_list_tile).setOnLongClickListener(v -> {
            new AdvertisementActivityLoader().startActivity(this, -1);
            return true;
        });
        findViewById(R.id.akkaskhoone_list_tile).setOnLongClickListener(v -> {
            new AkkaskhooneActivityLoader().startActivity(this, -1);
            return true;
        });
        findViewById(R.id.comments_list_tile).setOnLongClickListener(v -> {
            new CommentActivityLoader().startActivity(this, -1);
            return true;
        });
    }
}
