package ir.rafsanjan.admin.list;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.base.BaseActivity;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ListActivity extends BaseActivity {
    private ListFragment mFragment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frame_activity);

        FrameLayout frame = findViewById(R.id.frame_activity_frame);

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        mFragment = ListFragment.newInstance(getIntent().getExtras());
        ft.replace(frame.getId(), mFragment);

        ft.commit();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mFragment != null)
            mFragment.onActivityResult(requestCode, resultCode, data);
    }
}
