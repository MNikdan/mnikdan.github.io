package ir.rafsanjan.admin.list.loaders;

import android.app.Activity;

import java.io.Serializable;

import ir.rafsanjan.admin.edit.activities.loaders.AdCatsActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.BlocksActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.list.loaders.base.ListLoader;
import ir.rafsanjan.admin.list.models.Item;

public class BlocksListLoader extends ListLoader implements Serializable {
    public BlocksListLoader() {
        super("لیست بلوک‌ها");
    }

    @Override
    public String getUrl() {
        return "admin/block/get_blocks_list.php";
    }

    @Override
    public boolean hasAddButton() {
        return true;
    }

    @Override
    public void onAddClicked(Activity activity) {
        new BlocksActivityLoader()
                .type(EditActivityLoader.TYPE_ADD)
                .startAddActivity(activity);
    }

    @Override
    public void onItemClicked(Activity activity, Item item) {
        new BlocksActivityLoader()
                .type(EditActivityLoader.TYPE_EDIT)
                .startActivity(activity, item.id);
    }

    @Override
    public void onItemLongClicked(Activity activity, Item item) {}
}
