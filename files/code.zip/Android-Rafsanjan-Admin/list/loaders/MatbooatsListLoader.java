package ir.rafsanjan.admin.list.loaders;

import android.app.Activity;

import java.io.Serializable;

import ir.rafsanjan.admin.edit.activities.loaders.MatbooatsActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.SlidersActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.list.loaders.base.ListLoader;
import ir.rafsanjan.admin.list.models.Item;

public class MatbooatsListLoader extends ListLoader implements Serializable {
    public MatbooatsListLoader() {
        super("لیست مطبوعات");
    }

    @Override
    public String getUrl() {
        return "admin/matbooat/get_matbooats_list.php";
    }

    @Override
    public boolean hasAddButton() {
        return true;
    }

    @Override
    public void onAddClicked(Activity activity) {
        new MatbooatsActivityLoader()
                .type(EditActivityLoader.TYPE_ADD)
                .startAddActivity(activity);
    }

    @Override
    public void onItemClicked(Activity activity, Item item) {
        new MatbooatsActivityLoader()
                .type(EditActivityLoader.TYPE_EDIT)
                .startActivity(activity, item.id);
    }

    @Override
    public void onItemLongClicked(Activity activity, Item item) {}
}
