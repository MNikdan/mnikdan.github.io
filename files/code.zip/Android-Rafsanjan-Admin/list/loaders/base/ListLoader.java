package ir.rafsanjan.admin.list.loaders.base;

import android.app.Activity;
import android.content.Intent;

import java.io.Serializable;

import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.list.ListActivity;
import ir.rafsanjan.admin.list.models.Item;

public abstract class ListLoader implements Serializable {
    public static final int LIST_ITEM_REQUEST_CODE = 7219;

    private String mTitle;

    public abstract String getUrl();

    public ListLoader(String title) {
        mTitle = title;
    }

    public void startActivity(Activity activity) {
        Intent intent = new Intent(activity, ListActivity.class);
        intent.putExtra("loader", this);
        if (mTitle != null)
            intent.putExtra("title", mTitle);
        activity.startActivity(intent);
    }

    public boolean hasSearch(){
        return false;
    }

    public boolean hasConfirmed( ){
        return false;
    }

    public abstract boolean hasAddButton();
    public abstract void onAddClicked(Activity activity);
    public abstract void onItemClicked(Activity activity, Item item);
    public abstract void onItemLongClicked(Activity activity, Item item);
}
