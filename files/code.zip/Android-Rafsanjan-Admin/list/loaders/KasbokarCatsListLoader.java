package ir.rafsanjan.admin.list.loaders;

import android.app.Activity;

import java.io.Serializable;

import ir.rafsanjan.admin.edit.activities.loaders.AdCatsActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.KasbokarActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.KasbokarCatsActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.list.loaders.base.ListLoader;
import ir.rafsanjan.admin.list.models.Item;

public class KasbokarCatsListLoader extends ListLoader implements Serializable {
    public KasbokarCatsListLoader() {
        super("لیست دسته‌بندی کسب و کار");
    }

    @Override
    public String getUrl() {
        return "admin/kasbokar_cat/get_kasbokar_cats_list.php";
    }

    @Override
    public boolean hasAddButton() {
        return true;
    }

    @Override
    public void onAddClicked(Activity activity) {
        new KasbokarCatsActivityLoader()
                .presetFather("godfather")
                .type(EditActivityLoader.TYPE_ADD)
                .startAddActivity(activity);
    }

    @Override
    public void onItemClicked(Activity activity, Item item) {
        new KasbokarCatsActivityLoader()
                .type(EditActivityLoader.TYPE_EDIT)
                .startActivity(activity, item.id);
    }

    @Override
    public void onItemLongClicked(Activity activity, Item item) {
        // id is the parent's id
        new KasbokarCatsActivityLoader()
                .presetFather(item.title)
                .type(EditActivityLoader.TYPE_LONG_ADD)
                .startAddActivity(activity);
    }

    @Override
    public boolean hasSearch() {
        return true;
    }
}
