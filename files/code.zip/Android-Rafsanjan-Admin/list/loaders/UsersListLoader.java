package ir.rafsanjan.admin.list.loaders;

import android.app.Activity;

import java.io.Serializable;

import ir.rafsanjan.admin.edit.activities.loaders.KasbokarCatsActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.UserActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.list.loaders.base.ListLoader;
import ir.rafsanjan.admin.list.models.Item;

public class UsersListLoader extends ListLoader implements Serializable {
    public UsersListLoader() {
        super("لیست کاربران");
    }

    @Override
    public String getUrl() {
        return "admin/user/get_users_list.php";
    }

    @Override
    public boolean hasAddButton() {
        return true;
    }

    @Override
    public void onAddClicked(Activity activity) {
        new UserActivityLoader()
                .type(EditActivityLoader.TYPE_ADD)
                .startAddActivity(activity);
    }

    @Override
    public void onItemClicked(Activity activity, Item item) {
        new UserActivityLoader()
                .type(EditActivityLoader.TYPE_EDIT)
                .startActivity(activity, item.id);
    }

    @Override
    public void onItemLongClicked(Activity activity, Item item) {}

    @Override
    public boolean hasSearch() {
        return true;
    }
}
