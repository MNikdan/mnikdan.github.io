package ir.rafsanjan.admin.list.loaders;

import android.app.Activity;

import java.io.Serializable;

import ir.rafsanjan.admin.edit.activities.loaders.AkkaskhooneActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.CommentActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.list.loaders.base.ListLoader;
import ir.rafsanjan.admin.list.models.Item;

public class CommentListLoader extends ListLoader implements Serializable {
    public CommentListLoader() {
        super("لیست کامنت‌ها");
    }

    @Override
    public String getUrl() {
        return "admin/comment/get_comment_list.php";
    }

    @Override
    public boolean hasAddButton() {
        return false;
    }

    @Override
    public void onAddClicked(Activity activity) {}

    @Override
    public void onItemClicked(Activity activity, Item item) {
        new CommentActivityLoader()
                .type(EditActivityLoader.TYPE_EDIT)
                .startActivity(activity, item.id);
    }

    @Override
    public void onItemLongClicked(Activity activity, Item item) {}

    @Override
    public boolean hasConfirmed() {
        return true;
    }
}
