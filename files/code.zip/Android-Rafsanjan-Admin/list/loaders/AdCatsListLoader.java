package ir.rafsanjan.admin.list.loaders;

import android.app.Activity;

import java.io.Serializable;

import ir.rafsanjan.admin.edit.activities.loaders.AdCatsActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.list.loaders.base.ListLoader;
import ir.rafsanjan.admin.list.models.Item;

public class AdCatsListLoader extends ListLoader implements Serializable {
    public AdCatsListLoader() {
        super("لیست دسته‌بندی آگهی‌ها");
    }

    @Override
    public String getUrl() {
        return "admin/ad_cat/get_ad_cats_list.php";
    }

    @Override
    public boolean hasAddButton() {
        return true;
    }

    @Override
    public void onAddClicked(Activity activity) {
        new AdCatsActivityLoader()
                .presetFather("godfather")
                .type(EditActivityLoader.TYPE_ADD)
                .startAddActivity(activity);
    }

    @Override
    public void onItemClicked(Activity activity, Item item) {
        new AdCatsActivityLoader()
                .type(EditActivityLoader.TYPE_EDIT)
                .startActivity(activity, item.id);
    }

    @Override
    public void onItemLongClicked(Activity activity, Item item) {
        // id is the parent's id
        new AdCatsActivityLoader()
                .presetFather(item.title)
                .type(EditActivityLoader.TYPE_LONG_ADD)
                .startAddActivity(activity);
    }

    @Override
    public boolean hasSearch() {
        return true;
    }
}
