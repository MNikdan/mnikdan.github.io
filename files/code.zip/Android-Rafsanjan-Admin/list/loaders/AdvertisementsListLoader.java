package ir.rafsanjan.admin.list.loaders;

import android.app.Activity;

import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import ir.rafsanjan.admin.AdminApplication;
import ir.rafsanjan.admin.chat.database.ad.AdType;
import ir.rafsanjan.admin.chat.management.ChatManager;
import ir.rafsanjan.admin.edit.activities.loaders.AdCatsActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.AdvertisementActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.list.loaders.base.ListLoader;
import ir.rafsanjan.admin.list.models.Item;
import ir.rafsanjan.admin.utils.Utils;

public class AdvertisementsListLoader extends ListLoader implements Serializable {
    public AdvertisementsListLoader() {
        super("لیست آگهی‌ها");
    }

    @Override
    public String getUrl() {
        return "admin/advertisement/get_advertisements_list.php";
    }

    @Override
    public boolean hasAddButton() {
        return false;
    }

    @Override
    public void onAddClicked(Activity activity) {}

    @Override
    public void onItemClicked(Activity activity, Item item) {
        new AdvertisementActivityLoader()
                .type(EditActivityLoader.TYPE_EDIT)
                .startActivity(activity, item.id);
    }

    @Override
    public void onItemLongClicked(Activity activity, Item item) {
        MaterialDialog dialog = new MaterialDialog.Builder(activity)
                .progress(true, 100)
                .title("در حال بارگزاری")
                .cancelable(false)
                .show();

        AdminApplication.volley.add(new StringRequest(
                Request.Method.POST,
                AdminApplication.BASE_URL + "admin/advertisement/get_phone_by_id.php?password=" + AdminApplication.PASSWORD + "&id=" + item.id,
                response -> {
                    try {
                        String phone = response.trim();
                        if(!phone.matches("\\d+(?:\\.\\d+)?"))
                            return;

                        ChatManager.goToInsideChat(activity, AdType.S, 0, phone);
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        if (dialog != null)
                            dialog.dismiss();
                    }
                },
                error -> {
                    if (dialog != null)
                        dialog.dismiss();
                }
        ));
    }

    @Override
    public boolean hasSearch() {
        return true;
    }

    @Override
    public boolean hasConfirmed() {
        return true;
    }
}
