package ir.rafsanjan.admin.list.loaders;

import android.app.Activity;

import java.io.Serializable;

import ir.rafsanjan.admin.edit.activities.loaders.BlocksActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.SlidersActivityLoader;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.list.loaders.base.ListLoader;
import ir.rafsanjan.admin.list.models.Item;

public class SlidersListLoader extends ListLoader implements Serializable {
    public SlidersListLoader() {
        super("لیست اسلایدر‌ها");
    }

    @Override
    public String getUrl() {
        return "admin/slider/get_sliders_list.php";
    }

    @Override
    public boolean hasAddButton() {
        return true;
    }

    @Override
    public void onAddClicked(Activity activity) {
        new SlidersActivityLoader()
                .type(EditActivityLoader.TYPE_ADD)
                .startAddActivity(activity);
    }

    @Override
    public void onItemClicked(Activity activity, Item item) {
        new SlidersActivityLoader()
                .type(EditActivityLoader.TYPE_EDIT)
                .startActivity(activity, item.id);
    }

    @Override
    public void onItemLongClicked(Activity activity, Item item) {}
}
