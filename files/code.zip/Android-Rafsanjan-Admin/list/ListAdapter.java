package ir.rafsanjan.admin.list;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.toolbox.RequestFuture;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.ref.WeakReference;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ir.rafsanjan.admin.AdminApplication;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.list.loaders.base.ListLoader;
import ir.rafsanjan.admin.list.models.Item;
import ir.rafsanjan.admin.utils.InfiniteAdapter;
import ir.rafsanjan.admin.utils.Utils;

import static android.app.Activity.RESULT_OK;
import static ir.rafsanjan.admin.list.loaders.base.ListLoader.LIST_ITEM_REQUEST_CODE;

public class ListAdapter extends InfiniteAdapter<Item> {
    private int mDownloadCount;
    private WeakReference<Activity> mActivity;
    private LinearLayoutManager mManager;
    private ListLoader mLoader;
    private String mSearch;
    private int mConfirmed;

    private List<Item> mItems = new ArrayList<>();

    public ListAdapter(Activity activity, LinearLayoutManager manager, ListLoader loader, String search, int confirmed) {
        this(activity, manager, loader, 4, 10, search, confirmed);
    }

    public ListAdapter(Activity activity, LinearLayoutManager manager, ListLoader loader, int downloadOffset, int downloadCount, String search, int confirmed) {
        super(downloadOffset);
        mActivity = new WeakReference<>(activity);
        mManager = manager;
        mLoader = loader;
        mDownloadCount = downloadCount;
        mSearch = search;
        mConfirmed = confirmed;
        setAsIsInitialEmpty();
    }

    @Override
    public RecyclerView.ViewHolder create(ViewGroup parent, int viewType) {
        return new ItemHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false));
    }

    @Override
    public int getCount() {
        return mItems.size();
    }

    @Override
    public int getEveryDownloadItemCount() {
        return mDownloadCount;
    }

    @Override
    public int getType(int position) {
        return 0;
    }

    @Override
    public List<Item> getMainItems() {
        return mItems;
    }

    @Override
    public void bind(RecyclerView.ViewHolder vh, int position) {
        Activity activity = mActivity.get();
        if (activity == null)
            return;

        ItemHolder holder = (ItemHolder) vh;
        Item item = mItems.get(position);

        holder.image.setImageDrawable(null);
        if (item.image == null || item.image.trim().isEmpty()) {
            holder.image.setVisibility(View.GONE);
        } else {
            holder.image.setVisibility(View.VISIBLE);
            Glide.with(activity).load(item.image.trim()).into(holder.image);
        }

        if (item.details == null || item.details.trim().isEmpty())
            holder.details.setVisibility(View.GONE);

        holder.title.setText(item.title);
        holder.text.setText(item.text);
        holder.details.setText(item.details);

        holder.card.setOnClickListener(v -> {
            Activity act = mActivity.get();
            if (act == null)
                return;
            mLoader.onItemClicked(act, item);
        });

        holder.card.setOnLongClickListener(v -> {
            Activity act = mActivity.get();
            if (act == null)
                return true;
            mLoader.onItemLongClicked(act, item);
            return true;
        });
    }

    @Override
    public synchronized List<Item> downloadNewItems() {
        try {
            int lastId;
            if (!mItems.isEmpty())
                lastId = mItems.get(mItems.size() - 1).id;
            else
                lastId = 0;

            RequestFuture<String> future = RequestFuture.newFuture();
            StringRequest request = new StringRequest(
                    Request.Method.GET,
                    AdminApplication.BASE_URL + mLoader.getUrl()
                            + "?password=" + AdminApplication.PASSWORD
                            + "&last_id=" + lastId
                            + "&search=" + mSearch
                            + "&confirmed=" + mConfirmed,
                    future,
                    future
            );
            AdminApplication.volley.add(request);

            try {
                String response = future.get();
                Type listType = new TypeToken<ArrayList<Item>>() {
                }.getType();
                return new Gson().fromJson(response, listType);
            } catch (ExecutionException | InterruptedException e) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void addItems(List<Item> newItems) {
        mItems.addAll(newItems);
    }

    public int findItemPositionById(int id) {
        for (int i = 0; i < mItems.size(); i++) {
            if (mItems.get(i).id == id)
                return i;
        }
        return -1;
    }

    @SuppressWarnings("unchecked")
    void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == LIST_ITEM_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            String action = data.getStringExtra("returned by");
            if (action == null)
                return;

            Map<String, String> params = (Map<String, String>) data.getSerializableExtra("params");
            String idString = params.get("id");
            if (!Utils.isInt(idString))
                return;
            int id = Integer.parseInt(idString);

            switch (action) {
                case "remove":
                    itemRemoved(id);
                    break;
                case "add":
                    itemAdded(getItemFromIntentData(data));
                    break;
                default:
                    itemEdited(getItemFromIntentData(data));
                    break;
            }
        }
    }

    private void itemEdited(Item newItem) {
        if (newItem == null)
            return;
        int position = findItemPositionById(newItem.id);
        if (position == -1)
            return;
        mItems.set(position, newItem);
        notifyItemChanged(position);
    }

    private void itemAdded(Item newItem) {
        if (newItem == null)
            return;
        mItems.add(0, newItem);
        if (mManager != null)
            mManager.scrollToPosition(0);
        notifyItemInserted(0);
    }

    private Item getItemFromIntentData(Intent data) {
        try {
            return new Gson().fromJson(
                    ((BooleanOutput) data.getSerializableExtra("output")).payload,
                    Item.class
            );
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void itemRemoved(int itemId) {
        int position = findItemPositionById(itemId);
        if (position == -1)
            return;
        mItems.remove(position);
        notifyItemRemoved(position);
    }

    private static class ItemHolder extends RecyclerView.ViewHolder {
        CardView card;
        ViewGroup layout;
        ImageView image;
        TextView title, text, details;

        public ItemHolder(@NonNull View itemView) {
            super(itemView);

            card = itemView.findViewById(R.id.list_item_card);
            layout = itemView.findViewById(R.id.list_item_layout);
            image = itemView.findViewById(R.id.list_item_image);
            title = itemView.findViewById(R.id.list_item_title);
            text = itemView.findViewById(R.id.list_item_text);
            details = itemView.findViewById(R.id.list_item_details);
        }
    }
}
