package ir.rafsanjan.admin.list;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.base.BaseFragment;
import ir.rafsanjan.admin.list.loaders.base.ListLoader;

public class ListFragment extends BaseFragment {
    private static final String[] CONFIRMED_CHOICES = new String[]{"همه", "در انتظار تایید", "تایید شده", "رد شده"};
    private static int getConfirmedFromString(String str) {
        for (int i = 0; i < CONFIRMED_CHOICES.length; i++) {
            if (CONFIRMED_CHOICES[i].equals(str))
                return i - 1;
        }
        return -1;
    }


    private RecyclerView mRecycler;
    private ListAdapter mAdapter;
    private ListLoader mLoader;
    private LinearLayoutManager mManager;
    private Spinner mSpinner;

    private String mSearch = "";
    private int mConfirmed = -1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_fragment, container, false);
        init(view);
        return view;
    }

    private void init(View view) {
        Bundle arguments = getArguments();
        assert arguments != null;

        String title = arguments.getString("title");
        if (title != null)
            ((TextView) view.findViewById(R.id.list_fragment_title)).setText(title);

        mSpinner = view.findViewById(R.id.list_fragment_confirmed_spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(view.getContext(), android.R.layout.simple_spinner_item, CONFIRMED_CHOICES);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpinner.setAdapter(adapter);
        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mConfirmed = getConfirmedFromString(CONFIRMED_CHOICES[position]);
                loadWithSearchAndConfirmed();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                mConfirmed = -1;
                loadWithSearchAndConfirmed();
            }
        });

        mRecycler = view.findViewById(R.id.list_fragment_recycler);
        mManager = new LinearLayoutManager(view.getContext());
        mRecycler.setLayoutManager(mManager);

        mLoader = (ListLoader) arguments.getSerializable("loader");
        assert mLoader != null;

        loadWithSearchAndConfirmed();

        View button = view.findViewById(R.id.list_fragment_add);
        if (mLoader.hasAddButton()){
            button.setOnClickListener(v -> mLoader.onAddClicked((Activity) v.getContext()));
            button.setVisibility(View.VISIBLE);
        } else {
            button.setVisibility(View.GONE);
        }

        EditText searchEdit = view.findViewById(R.id.list_fragment_search);
        if (mLoader.hasSearch()) {
            searchEdit.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    mSearch = searchEdit.getText().toString();
                    loadWithSearchAndConfirmed();
                    return true;
                }
                return false;
            });
            searchEdit.setVisibility(View.VISIBLE);
        } else {
            searchEdit.setVisibility(View.INVISIBLE);
        }

        if (mLoader.hasConfirmed())
            mSpinner.setVisibility(View.VISIBLE);
        else
            mSpinner.setVisibility(View.GONE);
    }

    private void loadWithSearchAndConfirmed() {
        Activity activity = getActivity();
        if (mRecycler == null || mManager == null || mLoader == null || activity == null)
            return;
        mAdapter = new ListAdapter(
                activity,
                mManager,
                mLoader,
                mSearch,
                mConfirmed
        );
        mRecycler.setAdapter(mAdapter);
    }

    public static ListFragment newInstance(Bundle args) {
        ListFragment fragment = new ListFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mAdapter != null)
            mAdapter.onActivityResult(requestCode, resultCode, data);
    }
}
