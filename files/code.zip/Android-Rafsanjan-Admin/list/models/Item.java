package ir.rafsanjan.admin.list.models;

public class Item {
    public int id;
    public String image, title, text, details, payload;
}
