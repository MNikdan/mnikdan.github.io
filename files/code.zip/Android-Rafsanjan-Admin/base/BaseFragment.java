package ir.rafsanjan.admin.base;

import androidx.fragment.app.Fragment;

public class BaseFragment extends Fragment {
}
