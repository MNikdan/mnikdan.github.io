package ir.rafsanjan.admin.base;

import java.util.Map;

import ir.rafsanjan.admin.edit.contents.base.EditContent;

public interface ContentsProvider {
    Map<String, EditContent> provideContents();
}
