package ir.rafsanjan.admin.base;

import java.io.Serializable;
import java.util.ArrayList;

import ir.rafsanjan.admin.edit.items.base.EditItem;

public interface EditItemContainer extends Serializable {
    ArrayList<EditItem> getEditItems();
}
