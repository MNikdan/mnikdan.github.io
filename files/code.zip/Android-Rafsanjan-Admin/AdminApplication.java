package ir.rafsanjan.admin;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.orhanobut.hawk.Hawk;

import java.lang.ref.WeakReference;

import androidx.multidex.MultiDexApplication;
import ir.rafsanjan.admin.chat.database.ChatDatabase;
import ir.rafsanjan.admin.chat.management.ChatDependent;
import ir.rafsanjan.admin.chat.management.ChatManager;
import ir.rafsanjan.admin.chat.work.FlushPendingMessagesWorker;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

import io.socket.client.Socket;

public class AdminApplication extends MultiDexApplication {
    public static final String BASE_URL = "http://khabarfoori24.ir/";
    public static final String DOWNLOAD_SERVER = "http://khabarfoori24.ir/";
    public static final String CHAT_SERVER = "http://rafsanjan-news.ir/";

    public static String PASSWORD = "unset";

    public static AdminApplication app;
    public static RequestQueue volley;
    public static Handler handler = new Handler();

    public Socket chatSocket;

    @Override
    public void onCreate() {
        super.onCreate();

        app = this;

        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/iransans.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build()
        );

        volley = Volley.newRequestQueue(this);
        Hawk.init(this).build();

        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
                if (activity instanceof ChatDependent)
                    ChatManager.currentChatDependent = new WeakReference<>((ChatDependent) activity);
            }

            @Override
            public void onActivityStarted(Activity activity) {
                if (activity instanceof ChatDependent)
                    ChatManager.currentChatDependent = new WeakReference<>((ChatDependent) activity);
            }

            @Override
            public void onActivityResumed(Activity activity) {
                if (activity instanceof ChatDependent) {
                    ChatManager.currentChatDependent = new WeakReference<>((ChatDependent) activity);
                    ChatManager.chatDependentActivityResumed();
                }
            }

            @Override
            public void onActivityPaused(Activity activity) {

            }

            @Override
            public void onActivityStopped(Activity activity) {

            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

            }

            @Override
            public void onActivityDestroyed(Activity activity) {
                if (activity instanceof ChatDependent) {
                    ChatManager.chatDependentActivityDestroyed();
                }
            }
        });
    }

    public void initChatStuff() {
        ChatDatabase.getChatDatabase();
        chatSocket = ChatManager.initChatSocket();
        ChatManager.flushPendingMessages(true);

        FlushPendingMessagesWorker.schedule();
    }
}
