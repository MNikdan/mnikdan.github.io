package ir.rafsanjan.admin.edit;

import android.content.Intent;
import android.os.Bundle;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.base.BaseActivity;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;

public class EditActivity extends BaseActivity {

    private EditFragment mFragment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frame_activity);

        FrameLayout frame = findViewById(R.id.frame_activity_frame);

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        mFragment = EditFragment.newInstance(getIntent().getExtras());
        ft.replace(frame.getId(), mFragment);

        ft.commit();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        ((EditActivityLoader) getIntent().getSerializableExtra("loader"))
                .onActivityResult(requestCode, resultCode, data);

        if (mFragment != null)
            mFragment.onActivityResult(requestCode, resultCode, data);
    }
}
