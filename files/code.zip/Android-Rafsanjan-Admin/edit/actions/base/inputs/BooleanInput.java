package ir.rafsanjan.admin.edit.actions.base.inputs;

import java.io.Serializable;

public class BooleanInput implements Serializable {
    public int id;
    public boolean confirmed = false;
}
