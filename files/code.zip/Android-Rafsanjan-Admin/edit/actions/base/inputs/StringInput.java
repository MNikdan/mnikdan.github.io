package ir.rafsanjan.admin.edit.actions.base.inputs;

import java.io.Serializable;

public class StringInput implements Serializable {
    public String data;
}
