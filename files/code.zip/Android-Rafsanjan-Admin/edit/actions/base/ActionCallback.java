package ir.rafsanjan.admin.edit.actions.base;

public interface ActionCallback<O> {
    void onFinished(O output, String tag);
}
