package ir.rafsanjan.admin.edit.actions.base.outputs;

import java.io.Serializable;

public class BooleanOutput implements Serializable {
    public int success;
    public String payload;
}
