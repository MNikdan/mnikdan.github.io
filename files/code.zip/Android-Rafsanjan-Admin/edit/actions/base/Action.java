package ir.rafsanjan.admin.edit.actions.base;

import android.app.Activity;

import java.io.Serializable;


public abstract class Action<I, O> implements Serializable {
    public abstract void act(Activity activity, I input, String tag, ActionCallback<O> callback);
}
