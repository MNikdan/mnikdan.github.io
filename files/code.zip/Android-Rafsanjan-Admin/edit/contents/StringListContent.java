package ir.rafsanjan.admin.edit.contents;

import com.google.gson.Gson;

import java.io.Serializable;
import java.util.ArrayList;

import ir.rafsanjan.admin.edit.contents.base.EditContent;

public class StringListContent implements EditContent, Serializable {
    protected ArrayList<String> mList;
    protected boolean mMulti = false;

    public StringListContent(ArrayList<String> list) {
        mList = list;
    }

    public StringListContent() {
        mList = new ArrayList<>();
    }

    public ArrayList<String> getList() {
        return mList;
    }

    public void add(String str) {
        mList.add(str);
    }

    public void remove(int index) {
        mList.remove(index);
    }

    @Override
    public String contentToString() {
        if (mMulti)
            return new Gson().toJson(mList);
        else if (mList.isEmpty())
            return "";
        else
            return mList.get(0);
    }

    public int size() {
        return mList.size();
    }

    public String get(int index) {
        return mList.get(index);
    }

    public void multi() {
        mMulti = true;
    }

    public boolean isEmpty() {
        return mList.isEmpty();
    }

    public void set(int index, String value) {
        mList.set(index, value);
    }
}
