package ir.rafsanjan.admin.edit.contents;

import java.io.Serializable;

import ir.rafsanjan.admin.edit.contents.base.EditContent;

public class AddressContent implements EditContent, Serializable {
    public String city, address, latitude, longitude;

    public AddressContent(String address, String city, String latitude, String longitude) {
        this.address = address;
        this.city = city;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    @Override
    public String contentToString() {
        return address + "_" + city + "_" + latitude + "_" + longitude;
    }
}
