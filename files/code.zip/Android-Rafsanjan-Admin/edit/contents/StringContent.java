package ir.rafsanjan.admin.edit.contents;

import java.io.Serializable;

import ir.rafsanjan.admin.edit.contents.base.EditContent;

public class StringContent implements EditContent, Serializable {
    public String content;

    public StringContent(String content) {
        this.content = content;
    }

    @Override
    public String contentToString() {
        return content;
    }
}
