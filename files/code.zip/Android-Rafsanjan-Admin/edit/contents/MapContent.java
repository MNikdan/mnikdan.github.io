package ir.rafsanjan.admin.edit.contents;

import com.google.gson.Gson;

import java.io.Serializable;
import java.util.ArrayList;

import ir.rafsanjan.admin.edit.contents.base.EditContent;
import ir.rafsanjan.admin.edit.contents.base.Tuple;

public class MapContent implements EditContent, Serializable {
    protected ArrayList<Tuple> mList;

    public MapContent(ArrayList<Tuple> list) {
        mList = list;
    }

    public MapContent() {
        mList = new ArrayList<>();
    }

    public ArrayList<Tuple> getList() {
        return mList;
    }

    public void add(Tuple t) {
        mList.add(t);
    }

    public void remove(int index) {
        mList.remove(index);
    }

    @Override
    public String contentToString() {
        return new Gson().toJson(mList);
    }

    public int size() {
        return mList.size();
    }

    public Tuple get(int index) {
        return mList.get(index);
    }

    public boolean isEmpty() {
        return mList.isEmpty();
    }

    public void set(int index, String key, String value) {
        mList.set(index, new Tuple(key, value));
    }
}
