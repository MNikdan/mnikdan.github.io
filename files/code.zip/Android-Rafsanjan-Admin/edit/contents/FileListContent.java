package ir.rafsanjan.admin.edit.contents;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;

public class FileListContent extends StringListContent implements Serializable {
    public FileListContent() {
        super();
    }

    public FileListContent(ArrayList<String> list) {
        super(list);
    }

    public FileListContent uploaded(Map<String, String> urls) {
        FileListContent newContent = new FileListContent();
        if (mMulti)
            newContent.multi();
        for (String path: mList) {
            newContent.add(urls.get(path));
        }
        return newContent;
    }
}
