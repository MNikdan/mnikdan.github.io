package ir.rafsanjan.admin.edit.contents;

import ir.rafsanjan.admin.edit.contents.base.EditContent;

public class BooleanContent implements EditContent {
    public boolean content;

    public BooleanContent(boolean content) {
        this.content = content;
    }

    @Override
    public String contentToString() {
        if (content)
            return "1";
        return "0";
    }
}
