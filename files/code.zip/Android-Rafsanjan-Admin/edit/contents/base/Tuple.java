package ir.rafsanjan.admin.edit.contents.base;

import java.io.Serializable;

public class Tuple implements Serializable {
    public String key, value;

    public Tuple(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
