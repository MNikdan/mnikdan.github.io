package ir.rafsanjan.admin.edit.contents.base;

import java.io.Serializable;

public interface EditContent extends Serializable {
    String contentToString();
}
