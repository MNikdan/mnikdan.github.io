package ir.rafsanjan.admin.edit;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import ir.rafsanjan.admin.base.ContentsProvider;
import ir.rafsanjan.admin.edit.contents.FileListContent;
import ir.rafsanjan.admin.edit.contents.base.EditContent;
import ir.rafsanjan.admin.edit.items.base.ActivityResultHandler;
import ir.rafsanjan.admin.edit.items.base.EditItem;
import ir.rafsanjan.admin.edit.items.base.EditableEditItem;

@SuppressLint("UseSparseArrays")
public class EditAdapter extends RecyclerView.Adapter<EditAdapter.EditVH> implements ContentsProvider {
    private List<EditItem> mItems;

    private Map<String, Integer> mViewTypes = new HashMap<>();
    private Map<Integer, EditItem> mSampleItems = new HashMap<>();

    public EditAdapter(List<EditItem> items) {
        mItems = items;
        setViewTypes();
    }

    private void setViewTypes() {
        int type = 0;
        for (EditItem item: mItems) {
            String className = item.getClass().getSimpleName();
            if (!mViewTypes.containsKey(className)) {
                mViewTypes.put(className, type);
                mSampleItems.put(type, item);
                type++;
            }
        }
    }

    @NonNull
    @Override
    public EditAdapter.EditVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mSampleItems.get(viewType).instantiateView(parent);
        return new EditVH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EditAdapter.EditVH holder, int position) {
        mItems.get(position).bind(holder.itemView, this);
    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }

    @Override
    public int getItemViewType(int position) {
        return mViewTypes.get(mItems.get(position).getClass().getSimpleName());
    }

    @Override
    public Map<String, EditContent> provideContents() {
        Map<String, EditContent> contents = new HashMap<>();
        for (EditItem item: mItems) {
            if (item.isParam() && item instanceof EditableEditItem) {
                EditContent content = ((EditableEditItem) item).getContent();
                contents.put(item.getTag(), content);
            }
        }
        return contents;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        for (EditItem item: mItems) {
            if (item instanceof ActivityResultHandler)
                ((ActivityResultHandler) item).onActivityResult(requestCode, resultCode, data);
        }
    }

    static class EditVH extends RecyclerView.ViewHolder {
        EditVH(@NonNull View itemView) {
            super(itemView);
        }
    }
}
