package ir.rafsanjan.admin.edit.items;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.edit.contents.BooleanContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.base.EditableEditItem;

public class OnOffItem extends EditableEditItem<View, EditHeader, BooleanContent> {
    public OnOffItem(EditHeader headers, BooleanContent defaultContent, String tag) {
        super(headers, defaultContent, tag);
    }

    @Override
    public void bindContent(View view) {
        Switch aSwitch = view.findViewById(R.id.onoff_edit_item_switch);

        aSwitch.setChecked(content.content);

        updateText(view);
    }

    private void updateText(View view){
        if (content == null || view == null)
            return;
        TextView textView = view.findViewById(R.id.onoff_edit_item_text);
        if (content.content)
            textView.setText("فعال");
        else
            textView.setText("غیرفعال");
    }

    @Override
    protected void setContentSynchronizer(View view) {
        Switch aSwitch = view.findViewById(R.id.onoff_edit_item_switch);
        aSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            content.content = isChecked;
            updateText((View) ((View) (buttonView.getParent())).getParent());
        });
    }

    @Override
    public void bindHeader(View view) {
        // nothing to do here
    }

    @Override
    public View instantiateInnerView(@NonNull ViewGroup parent) {
        return LayoutInflater.from(parent.getContext())
                .inflate(R.layout.onoff_edit_item, parent, false);
    }
}
