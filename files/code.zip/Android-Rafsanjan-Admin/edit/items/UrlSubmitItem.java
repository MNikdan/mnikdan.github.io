package ir.rafsanjan.admin.edit.items;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import ir.rafsanjan.admin.AdminApplication;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.base.ContentsProvider;
import ir.rafsanjan.admin.edit.actions.base.Action;
import ir.rafsanjan.admin.edit.actions.base.ActionCallback;
import ir.rafsanjan.admin.edit.contents.FileListContent;
import ir.rafsanjan.admin.edit.contents.base.EditContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.base.ActionEditItem;
import ir.rafsanjan.admin.utils.MultipleFileUploader;
import saman.zamani.persiandate.PersianDate;

@SuppressWarnings("unchecked")
public class UrlSubmitItem<O extends Serializable> extends ActionEditItem<View, EditHeader, HashMap, O> {
    private String mText = "تایید";
    private boolean hasPubdate = false;

    public UrlSubmitItem(Class<O> oClass, String url, String tag) {
        super(null, new Action<HashMap, O>() {
            @Override
            public void act(Activity activity, HashMap input, String tag, ActionCallback<O> callback) {
                MaterialDialog dialog = new MaterialDialog.Builder(activity)
                        .progress(true, 100)
                        .title("در حال بارگزاری")
                        .cancelable(false)
                        .show();

                AdminApplication.volley.add(new StringRequest(
                        Request.Method.POST,
                        AdminApplication.BASE_URL + url,
                        response -> {
                            try {
                                callback.onFinished(new Gson().fromJson(response, oClass), tag);
                            } catch (Exception e) {
                                e.printStackTrace();
                            } finally {
                                if (dialog != null)
                                    dialog.dismiss();
                            }
                        },
                        error -> {
                            if (dialog != null)
                                dialog.dismiss();
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<>(input);
                        params.put("password", AdminApplication.PASSWORD);
                        return params;
                    }
                });
            }
        }, tag);
    }

    public UrlSubmitItem<O> text(String text) {
        mText = text;
        return this;
    }

    @Override
    public View instantiateInnerView(@NonNull ViewGroup parent) {
        return LayoutInflater.from(parent.getContext()).inflate(R.layout.submit_item, parent, false);
    }

    @Override
    protected void bindInner(View innerView, ContentsProvider contentsProvider) {
        Button button = innerView.findViewById(R.id.submit_item_button);
        button.setText(mText);
        button.setOnClickListener(v -> {
            WeakReference<Activity> activityWeak = new WeakReference<>((Activity) v.getContext());
            Map<String, EditContent> contents = contentsProvider.provideContents();

            MultipleFileUploader uploader = new MultipleFileUploader(tag);
            for (EditContent content: contents.values()) {
                if (content instanceof FileListContent)
                    uploader.addFiles(((FileListContent) content).getList());
            }

            if (uploader.isEmpty()) {
                contentsReady(activityWeak, contents);
                return;
            }

            Activity activity = activityWeak.get();
            if (activity == null)
                return;

            MaterialDialog dialog = new MaterialDialog.Builder(activity)
                    .progress(true, 100)
                    .title("در حال آپلود")
                    .cancelable(false)
                    .show();

            WeakReference<MaterialDialog> dialogWeak = new WeakReference<>(dialog);
            new Thread(() -> uploader.execute(new MultipleFileUploader.MultiUploadListener() {
                @Override
                public void onSuccess(Map<String, String> urls, String tag) {
                    MaterialDialog d = dialogWeak.get();
                    if (d != null)
                        d.dismiss();

                    HashMap<String, EditContent> newContents = new HashMap<>();
                    for (Map.Entry<String, EditContent> entry: contents.entrySet()) {
                        EditContent content = entry.getValue();
                        String key = entry.getKey();
                        if (content instanceof FileListContent)
                            content = ((FileListContent) content).uploaded(urls);
                        newContents.put(key, content);
                    }

                    contentsReady(activityWeak, newContents);
                }

                @Override
                public void onFailure(String tag) {
                    MaterialDialog d = dialogWeak.get();
                    if (d != null)
                        d.dismiss();
                }
            })).start();
        });
    }

    private void contentsReady(WeakReference<Activity> activityWeak, Map<String, EditContent> contents) {
        Activity activity = activityWeak.get();
        if (activity == null)
            return;

        activity.runOnUiThread(() -> {
            act(
                    activity,
                    generateInputFromContents(contents),
                    tag,
                    getCallback(activity)
            );
        });
    }

    private ActionCallback<O> getCallback(Activity activity) {
        WeakReference<Activity> weakActivity = new WeakReference<>(activity);
        return (output, tag) -> {
            Activity act = weakActivity.get();
            if (act == null)
                return;
            Intent data = new Intent();
            data.putExtra("returned by", tag);
            data.putExtra("params", addedParams);
            data.putExtra("output", output);
            act.setResult(Activity.RESULT_OK, data);
            act.finish();
        };
    }

    private HashMap<String, String> generateInputFromContents(Map<String, EditContent> contents) {
        HashMap<String, String> result = new HashMap<>(addedParams);
        if (hasPubdate)
            result.put("pubdate", getPubdate());

        for (Map.Entry<String, EditContent> entry: contents.entrySet()) {
            result.put(entry.getKey(), entry.getValue().contentToString());
        }
        return result;
    }

    private HashMap<String, String> addedParams = new HashMap<>();
    public UrlSubmitItem<O> addParam(String key, String value) {
        addedParams.put(key, value);
        return this;
    }

    public UrlSubmitItem<O> addPubdate() {
        hasPubdate = true;
        return this;
    }

    private static String getPubdate() {
        PersianDate persianDate = new PersianDate(System.currentTimeMillis());
        StringBuilder pubdate = new StringBuilder();
        pubdate.append(persianDate.getShYear()).append(" ");
        pubdate.append(persianDate.getShMonth()).append(" ");
        pubdate.append(persianDate.getShDay()).append(" ");
        pubdate.append(persianDate.getHour()).append(" ");
        pubdate.append(persianDate.getMinute()).append(" ");
        pubdate.append(persianDate.getSecond());
        return pubdate.toString();
    }
}
