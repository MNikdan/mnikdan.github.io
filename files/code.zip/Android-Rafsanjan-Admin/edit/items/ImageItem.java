package ir.rafsanjan.admin.edit.items;

import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.io.Serializable;

import androidx.annotation.NonNull;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.base.EditableEditItem;

public class ImageItem extends EditableEditItem<ImageView, EditHeader, StringContent> implements Serializable {
    public ImageItem(EditHeader headers, StringContent defaultContent, String tag) {
        super(headers, defaultContent, tag);
    }

    @Override
    public void bindContent(ImageView imageView) {
        Glide.with(imageView.getContext()).load(content.content.trim()).into(imageView);
    }

    @Override
    protected void setContentSynchronizer(ImageView imageView) {
        // nothing to do here
    }

    @Override
    public void bindHeader(ImageView imageView) {
        // nothing to do here
    }

    @Override
    public ImageView instantiateInnerView(@NonNull ViewGroup parent) {
        return (ImageView) instantiateInnerView(parent, R.layout.image_item);
    }
}
