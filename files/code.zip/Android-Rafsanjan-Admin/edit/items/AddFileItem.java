package ir.rafsanjan.admin.edit.items;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;

import java.io.File;
import java.io.Serializable;

import androidx.annotation.NonNull;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.edit.contents.FileListContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.base.ActivityResultHandler;
import ir.rafsanjan.admin.edit.items.base.EditableEditItem;
import ir.rafsanjan.admin.utils.FullSizeImageActivity;
import ir.rafsanjan.admin.utils.Utils;

import static android.app.Activity.RESULT_OK;

public class AddFileItem extends EditableEditItem<View, EditHeader, FileListContent> implements Serializable, ActivityResultHandler {
    public static final int FILE_TYPE_IMAGE = 0;
    public static final int FILE_TYPE_AUDIO = 1;
    public static final int FILE_TYPE_VIDEO = 2;
    public static final int FILE_TYPE_ALL = 3;

    private static final int PICK_FILE_REQUEST_CODE = 12309;

    private int mRequestCode = PICK_FILE_REQUEST_CODE;

    private transient ViewGroup mLayout;
    private int mFileType;
    private boolean mMulti = false;

    public AddFileItem(EditHeader headers, FileListContent defaultContent, int fileType, String tag) {
        super(headers, defaultContent, tag);
        mFileType = fileType;
    }

    public AddFileItem multi() {
        mMulti = true;
        content.multi();
        return this;
    }

    public AddFileItem requestCode(int requestCode) {
        mRequestCode = requestCode;
        return this;
    }

    @Override
    public void bindContent(View view) {
        mLayout = view.findViewById(R.id.add_file_item_files_layout);
        mLayout.removeAllViews();

        for (int i = 0; i < content.size(); i++) {
            String filePath = content.get(i);
            addFileItem(filePath, i + 1);
        }

        Button button = view.findViewById(R.id.add_file_item_add_button);
        String buttonTitle = "انتخاب " + getPersianName();
        button.setText(buttonTitle);
        button.setOnClickListener(v -> {
            if (!mMulti && !content.isEmpty())
                return;

            Intent i;
            if (mFileType == FILE_TYPE_ALL) {
                i = new Intent(Intent.ACTION_PICK);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*", "video/*", "audio/*"});
            } else {
                Uri uri = mFileType == FILE_TYPE_IMAGE ? android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI :
                        mFileType == FILE_TYPE_AUDIO ? android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI :
                                android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                i = new Intent(Intent.ACTION_PICK, uri);
                if (mFileType == FILE_TYPE_IMAGE && mMulti)
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }
            ((Activity) v.getContext()).startActivityForResult(i, mRequestCode);
        });
        button.setOnLongClickListener(v -> {
            if (!mMulti && !content.isEmpty())
                return true;
            openAddUrlDialog(v);
            return true;
        });
    }

    private void openAddUrlDialog(View v) {
        new MaterialDialog.Builder(v.getContext())
                .title("لینک " + getPersianName())
                .cancelable(true)
                .input("Link", "", false, (dialog, input) -> {
                    dialog.dismiss();
                    String link = input == null? "": input.toString().trim();
                    if (link.startsWith("http"))
                        add(link);
                })
                .show();
    }

    @Override
    protected void setContentSynchronizer(View view) {
        // nothing to do here
    }

    @Override
    public void bindHeader(View view) {
        // nothing to do here
    }

    @Override
    public View instantiateInnerView(@NonNull ViewGroup parent) {
        return LayoutInflater.from(parent.getContext())
                .inflate(R.layout.add_file_item, parent, false);
    }

    private String getPersianName() {
        switch (mFileType) {
            case FILE_TYPE_IMAGE:
                return "تصویر";
            case FILE_TYPE_AUDIO:
                return "صدا";
            case FILE_TYPE_VIDEO:
                return "ویدئو";
            case FILE_TYPE_ALL:
                return "فایل";
        }
        return null;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != mRequestCode || resultCode != RESULT_OK || data == null)
            return;

        if (mFileType == FILE_TYPE_IMAGE) {
            ClipData clipdata = data.getClipData();
            if (clipdata == null || !mMulti)
                onActivitySingleResult(data);
            else {
                for (int i = 0; i < clipdata.getItemCount(); i++) {
                    String path = Utils.getUriRealPath(clipdata.getItemAt(i).getUri());
                    add(path);
                }
            }
        } else
            onActivitySingleResult(data);
    }

    private void onActivitySingleResult(Intent data) {
        Uri uri = data.getData();
        if (uri == null)
            return;

        String path = Utils.getUriRealPath(uri);
        add(path);
    }

    private void add(String newItem) {
        content.add(newItem);
        addFileItem(newItem, content.size());
    }

    private void addFileItem(String filePath, int fileIndex) {
        if (mLayout == null)
            return;

        View item = LayoutInflater.from(mLayout.getContext())
                .inflate(R.layout.add_file_item_item, mLayout, false);
        mLayout.addView(item);

        TextView text = item.findViewById(R.id.add_file_item_item_text);
        ImageView delete = item.findViewById(R.id.add_file_item_item_delete);

        text.setText(Utils.replaceDigitsWithPersian(getPersianName()));
        text.setOnClickListener(v -> previewFile(v.getContext(), filePath));
        delete.setTag(fileIndex - 1);
        delete.setOnClickListener(v -> {
            int idx = (int) v.getTag();
            content.remove(idx);
            mLayout.removeViewAt(idx);

            for (int i = 0; i < mLayout.getChildCount(); i++) {
                mLayout.getChildAt(i).findViewById(R.id.add_file_item_item_delete).setTag(i);
            }
        });
    }

    private void previewFile(Context context, String filePath) {
        if (mLayout == null)
            return;
        if (filePath.endsWith(".jpg") || filePath.endsWith(".png")) {
            Intent intent = new Intent(context, FullSizeImageActivity.class);
            intent.putExtra("uri", filePath.startsWith("http")? Uri.parse(filePath): Uri.fromFile(new File(filePath)));
            context.startActivity(intent);

        }
    }
}
