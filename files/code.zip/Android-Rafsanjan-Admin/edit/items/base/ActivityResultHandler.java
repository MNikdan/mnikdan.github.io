package ir.rafsanjan.admin.edit.items.base;

import android.content.Intent;

public interface ActivityResultHandler {
    void onActivityResult(int requestCode, int resultCode, Intent data);
}
