package ir.rafsanjan.admin.edit.items.base;

import android.app.Activity;
import android.view.View;

import java.io.Serializable;

import ir.rafsanjan.admin.edit.actions.base.Action;
import ir.rafsanjan.admin.edit.actions.base.ActionCallback;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;

public abstract class ActionEditItem<V extends View, H extends EditHeader, I, O extends Serializable> extends EditItem<V, H> implements Serializable {
    private Action<I, O> mAction;

    public ActionEditItem(H headers, Action<I, O> action, String tag) {
        super(headers, tag);
        mAction = action;
    }

    public void act(Activity activity, I input, String tag, ActionCallback<O> callback) {
        mAction.act(activity, input, tag, callback);
    }
}
