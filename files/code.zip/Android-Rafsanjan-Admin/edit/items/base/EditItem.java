package ir.rafsanjan.admin.edit.items.base;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.Serializable;

import androidx.annotation.NonNull;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.base.ContentsProvider;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;

public abstract class EditItem<V extends View, H extends EditHeader> implements Serializable {
    private H header;
    protected String tag;
    private boolean mIsParam = true;

    public EditItem(H header, String tag) {
        this.header = header;
        this.tag = tag;
    }

    public EditItem<V, H> asParam() {
        mIsParam = true;
        return this;
    }

    public String getTag() {
        return tag;
    }

    public abstract V instantiateInnerView(@NonNull ViewGroup parent);

    protected static View instantiateInnerView(ViewGroup parent, int layoutId) {
        return LayoutInflater.from(parent.getContext())
                .inflate(layoutId, parent, false);
    }

    protected abstract void bindInner(V innerView, ContentsProvider contentsProvider);

    @SuppressWarnings("unchecked")
    public void bind(View v, ContentsProvider contentsProvider) {
        TextView titleView = v.findViewById(R.id.edit_container_title);
        if (header == null) {
            titleView.setVisibility(View.GONE);
            titleView.setText("");
        } else {
            titleView.setText(header.header);
            titleView.setVisibility(View.VISIBLE);
        }

        bindInner((V) v.getTag(), contentsProvider);
    }

    public View instantiateView(@NonNull ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.edit_container_view, parent, false);
        ViewGroup layout = view.findViewById(R.id.edit_container_layout);

        V innerView = instantiateInnerView(layout);
        layout.addView(innerView);

        view.setTag(innerView);

        return view;
    }

    public boolean isParam() {
        return mIsParam;
    }

    public EditItem transformToAddMode() {
        return this;
    }
}
