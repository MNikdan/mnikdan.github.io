package ir.rafsanjan.admin.edit.items.base;

import android.view.View;

import java.io.Serializable;

import ir.rafsanjan.admin.base.ContentsProvider;
import ir.rafsanjan.admin.edit.contents.base.EditContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;

public abstract class EditableEditItem<V extends View, H extends EditHeader, C extends EditContent> extends EditItem<V, H> implements Serializable {
    protected C content;

    public EditableEditItem(H headers, C defaultContent, String tag) {
        super(headers, tag);
        this.content = defaultContent;
    }

    public abstract void bindContent(V v);

    public EditContent getContent() {
        return content;
    }

    protected abstract void setContentSynchronizer(V v);

    public abstract void bindHeader(V v);

    @Override
    protected void bindInner(V innerView, ContentsProvider contentsProvider) {
        bindContent(innerView);
        setContentSynchronizer(innerView);
        bindHeader(innerView);
    }
}
