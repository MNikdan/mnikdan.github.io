package ir.rafsanjan.admin.edit.items;

import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.Locale;

import androidx.annotation.NonNull;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.edit.contents.AddressContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.base.EditableEditItem;

public class AddressItem extends EditableEditItem<View, EditHeader, AddressContent> {

    public AddressItem(EditHeader headers, AddressContent defaultContent, String tag) {
        super(headers, defaultContent, tag);
    }

    @Override
    public void bindContent(View view) {
        TextView cityView = view.findViewById(R.id.address_item_city);
        TextView addressView = view.findViewById(R.id.address_item_address);

        cityView.setText(content.city);
        addressView.setText(content.address);

        view.findViewById(R.id.address_item_button).setOnClickListener(v -> {
            String uri = String.format(Locale.ENGLISH, "geo:%s,%s", content.latitude, content.longitude);
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            v.getContext().startActivity(intent);
        });
    }

    @Override
    protected void setContentSynchronizer(View view) {
        // nothing to do here
    }

    @Override
    public void bindHeader(View view) {
        // nothing to do here
    }

    @Override
    public View instantiateInnerView(@NonNull ViewGroup parent) {
        return LayoutInflater.from(parent.getContext())
                .inflate(R.layout.address_item, parent, false);
    }
}
