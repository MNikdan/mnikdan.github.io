package ir.rafsanjan.admin.edit.items;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.Serializable;

import androidx.annotation.NonNull;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.edit.contents.MapContent;
import ir.rafsanjan.admin.edit.contents.base.Tuple;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.base.EditableEditItem;

public class MapItem extends EditableEditItem<View, EditHeader, MapContent> implements Serializable {
    private transient ViewGroup mLayout;

    public MapItem(EditHeader headers, MapContent defaultContent, String tag) {
        super(headers, defaultContent, tag);
    }

    @Override
    public void bindContent(View view) {
        mLayout = view.findViewById(R.id.map_item_items_layout);
        mLayout.removeAllViews();

        for (int i = 0; i < content.size(); i++) {
            Tuple t = content.get(i);
            addKeyValueItem(t, i + 1);
        }

        Button button = view.findViewById(R.id.map_item_add_button);
        button.setOnClickListener(v -> {
            Tuple newT = new Tuple("", "");
            content.add(newT);
            addKeyValueItem(newT, content.size());
        });
    }

    @Override
    protected void setContentSynchronizer(View view) {
        // nothing to do here
    }

    @Override
    public void bindHeader(View view) {
        // nothing to do here
    }

    @Override
    public View instantiateInnerView(@NonNull ViewGroup parent) {
        return LayoutInflater.from(parent.getContext())
                .inflate(R.layout.map_item, parent, false);
    }

    private void addKeyValueItem(Tuple newItem, int fileIndex) {
        if (mLayout == null)
            return;

        View item = LayoutInflater.from(mLayout.getContext())
                .inflate(R.layout.map_item_item, mLayout, false);
        mLayout.addView(item);

        final EditText keyEdit = item.findViewById(R.id.map_item_item_key);
        final EditText valueEdit = item.findViewById(R.id.map_item_item_value);
        ImageView delete = item.findViewById(R.id.map_item_item_delete);

        keyEdit.setText(newItem.key);
        valueEdit.setText(newItem.value);

        keyEdit.setTag(fileIndex - 1);
        valueEdit.setTag(fileIndex - 1);
        delete.setTag(fileIndex - 1);

        delete.setOnClickListener(v -> {
            int idx = (int) v.getTag();
            content.remove(idx);
            mLayout.removeViewAt(idx);

            for (int i = 0; i < mLayout.getChildCount(); i++) {
                mLayout.getChildAt(i).findViewById(R.id.map_item_item_key).setTag(i);
                mLayout.getChildAt(i).findViewById(R.id.map_item_item_value).setTag(i);
                mLayout.getChildAt(i).findViewById(R.id.map_item_item_delete).setTag(i);
            }
        });

        keyEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int idx = (int) keyEdit.getTag();
                content.set(idx, s.toString(), valueEdit.getText().toString());
            }
        });

        valueEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int idx = (int) valueEdit.getTag();
                content.set(idx, keyEdit.getText().toString(), s.toString());
            }
        });
    }
}
