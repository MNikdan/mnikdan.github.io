package ir.rafsanjan.admin.edit.items;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.Serializable;

import androidx.annotation.NonNull;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.base.EditableEditItem;

public class TextItem extends EditableEditItem<TextView, EditHeader, StringContent> implements Serializable {
    public TextItem(EditHeader headers, StringContent defaultContent, String tag) {
        super(headers, defaultContent, tag);
    }

    @Override
    public void bindContent(TextView textView) {
        textView.setText(content.content);

        if (content.content != null && content.content.startsWith("09") && content.content.length() == 11)
            textView.setOnClickListener(v -> dialContent(v.getContext()));
        else
            textView.setOnClickListener(null);
    }

    private void dialContent(Context context) {
        Intent callIntent = new Intent(Intent.ACTION_DIAL);
        callIntent.setData(Uri.parse("tel:" + content.content));
        context.startActivity(callIntent);
    }

    @Override
    protected void setContentSynchronizer(TextView textView) {
        // nothing to do here
    }

    @Override
    public void bindHeader(TextView textView) {
        // nothing to do here
    }

    @Override
    public TextView instantiateInnerView(@NonNull ViewGroup parent) {
        return (TextView) instantiateInnerView(parent, R.layout.text_item);
    }
}
