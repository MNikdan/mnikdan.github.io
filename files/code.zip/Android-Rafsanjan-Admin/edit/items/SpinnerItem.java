package ir.rafsanjan.admin.edit.items;

import android.app.Activity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import ir.rafsanjan.admin.AdminApplication;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.edit.contents.FileListContent;
import ir.rafsanjan.admin.edit.contents.StringListContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.base.EditableEditItem;
import ir.rafsanjan.admin.utils.Utils;

public class SpinnerItem extends EditableEditItem<View, EditHeader, StringListContent> implements Serializable{
    private transient ViewGroup mLayout;
    private boolean mMulti = false;
    private String mPersianName, mChoicesUrl;
    private List<String> mPossibleChoices;

    public SpinnerItem(EditHeader headers, StringListContent defaultContent, String persianName, String choicesUrl, String tag) {
        super(headers, defaultContent, tag);
        mPersianName = persianName;
        mChoicesUrl = choicesUrl;
        if (content.isEmpty())
            content.add("");
    }

    public SpinnerItem multi() {
        mMulti = true;
        content.multi();
        return this;
    }

    @Override
    public void bindContent(View view) {
        mLayout = view.findViewById(R.id.spinner_item_spinners_layout);
        mLayout.removeAllViews();

        if (mPossibleChoices != null) {
            addSpinnerItems(view);
        } else {
            Button button = view.findViewById(R.id.spinner_item_add_button);
            button.setVisibility(View.GONE);
            button.setOnClickListener(null);

            ProgressBar pb = new ProgressBar(mLayout.getContext());
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.gravity = Gravity.CENTER_HORIZONTAL;
            mLayout.addView(pb, params);

            WeakReference<View> weakView = new WeakReference<>(view);
            StringRequest request = new StringRequest(
                    Request.Method.GET,
                    AdminApplication.BASE_URL + mChoicesUrl + "?password=" + AdminApplication.PASSWORD,
                    response -> {
                        try {
                            Type listType = new TypeToken<ArrayList<String>>(){}.getType();
                            mPossibleChoices = new Gson().fromJson(response, listType);
                        } catch (Exception e){
                            e.printStackTrace();
                            errorGettingChoices();
                        }

                        if (mPossibleChoices != null) {
                            View v = weakView.get();
                            if (v == null)
                                return;
                            ((Activity) v.getContext()).runOnUiThread(() -> {
                                ((ViewGroup) v.findViewById(R.id.spinner_item_spinners_layout)).removeAllViews();
                                addSpinnerItems(v);
                            });
                        }
                    },
                    error -> {
                        error.printStackTrace();
                        errorGettingChoices();
                    }
            );
            AdminApplication.volley.add(request);
        }
    }

    private void errorGettingChoices() {
        Toast.makeText(AdminApplication.app, "خطا در ارتباط با سرور", Toast.LENGTH_SHORT).show();
    }

    private void addSpinnerItems(View view) {
        for (int i = 0; i < content.size(); i++) {
            String selectedItem = content.get(i);
            addSpinnerItem(selectedItem, i + 1);
        }

        Button button = view.findViewById(R.id.spinner_item_add_button);
        button.setVisibility(View.VISIBLE);
        if (!mMulti) {
            button.setText(null);
            button.setOnClickListener(null);
            button.setVisibility(View.GONE);
        } else {
            String buttonTitle = "اضافه کردن " + mPersianName;
            button.setText(buttonTitle);
            button.setOnClickListener(v -> {
                String newItem = "";
                content.add(newItem);
                addSpinnerItem(newItem, content.size());
            });
            button.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void setContentSynchronizer(View view) {
        // nothing to do here
    }

    @Override
    public void bindHeader(View view) {
        // nothing to do here
    }

    @Override
    public View instantiateInnerView(@NonNull ViewGroup parent) {
        return LayoutInflater.from(parent.getContext())
                .inflate(R.layout.spinner_item, parent, false);
    }

    private void addSpinnerItem(String selectedItem, int spinnerIndex) {
        if (mLayout == null)
            return;

        View item = LayoutInflater.from(mLayout.getContext())
                .inflate(R.layout.spinner_item_item, mLayout, false);
        mLayout.addView(item);

        TextView text = item.findViewById(R.id.spinner_item_item_text);
        Spinner spinner = item.findViewById(R.id.spinner_item_item_spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(mLayout.getContext(), android.R.layout.simple_spinner_item, mPossibleChoices);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        if (selectedItem != null && !selectedItem.isEmpty())
            spinner.setSelection(mPossibleChoices.indexOf(selectedItem));


        text.setText(Utils.replaceDigitsWithPersian(null));

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                content.set(spinnerIndex - 1, parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                content.set(spinnerIndex - 1, "");
            }
        });

    }
}
