package ir.rafsanjan.admin.edit.items;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.ViewGroup;
import android.widget.EditText;

import java.io.Serializable;

import androidx.annotation.NonNull;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.base.EditableEditItem;

public class StringEditItem extends EditableEditItem<EditText, EditHeader, StringContent> implements Serializable {
    public StringEditItem(EditHeader headers, StringContent defaultContent, String tag) {
        super(headers, defaultContent, tag);
    }

    @Override
    public void bindContent(EditText editText) {
        editText.setText(content.content);
    }

    @Override
    protected void setContentSynchronizer(EditText editText) {
        TextWatcher watcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                content.content = s.toString();
            }
        };
        if (editText.getTag() != null)
            editText.removeTextChangedListener((TextWatcher) editText.getTag());
        editText.setTag(watcher);
        editText.addTextChangedListener(watcher);
    }

    @Override
    public void bindHeader(EditText editText) {
        // nothing to do here
    }

    @Override
    public EditText instantiateInnerView(@NonNull ViewGroup parent) {
        return (EditText) instantiateInnerView(parent, R.layout.string_edit_item);
    }
}
