package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.Message;
import ir.rafsanjan.admin.edit.contents.FileListContent;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.AddFileItem;
import ir.rafsanjan.admin.edit.items.StringEditItem;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;

public class MessagesActivityLoader extends EditActivityLoader<Message> implements Serializable {
    public MessagesActivityLoader(int requestCode) {
        super(Message.class, requestCode);
    }

    public MessagesActivityLoader() {
        super(Message.class);
    }

    @Override
    protected Message getOfflineDefaults() {
        if (mType == TYPE_EDIT)
            return super.getOfflineDefaults();
        return new Message();
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "": "admin/message/get_message.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new StringEditItem(
                new EditHeader("تیتر"),
                new StringContent(mDefaults.title),
                "title"
        ).asParam());

        items.add(new StringEditItem(
                new EditHeader("خلاصه"),
                new StringContent(mDefaults.description),
                "description"
        ).asParam());

        items.add(new StringEditItem(
                new EditHeader("توضیحات"),
                new StringContent(mDefaults.text),
                "text"
        ).asParam());

        items.add(new AddFileItem(
                new EditHeader("محتوا"),
                new FileListContent(mType == TYPE_EDIT? new ArrayList<>(Collections.singletonList(mDefaults.data)) : new ArrayList<>()),
                AddFileItem.FILE_TYPE_ALL,
                "data"
        ));

        if (mType == TYPE_EDIT)
            items.add(new UrlSubmitItem<>(
                    BooleanOutput.class,
                    "admin/message/remove_message.php",
                    "remove"
            ).text("حذف").addParam("id", String.valueOf(mDefaults.id)));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/message/add_edit_message.php",
                mType == TYPE_EDIT? "edit": "add"
        ).text(mType == TYPE_EDIT? "ویرایش": "تایید").addParam("id", String.valueOf(mDefaults.id)));
        return items;
    }
}
