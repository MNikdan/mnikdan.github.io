package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.AdCat;
import ir.rafsanjan.admin.edit.contents.FileListContent;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.AddFileItem;
import ir.rafsanjan.admin.edit.items.StringEditItem;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;

import static ir.rafsanjan.admin.list.loaders.base.ListLoader.LIST_ITEM_REQUEST_CODE;

public class AdCatsActivityLoader extends EditActivityLoader<AdCat> implements Serializable {
    public AdCatsActivityLoader(int requestCode) {
        super(AdCat.class, requestCode);
    }

    public AdCatsActivityLoader() {
        super(AdCat.class);
    }

    private String mPresetFather;
    public AdCatsActivityLoader presetFather(String father) {
        mPresetFather = father;
        return this;
    }

    @Override
    protected AdCat getOfflineDefaults() {
        if (mType == TYPE_EDIT)
            return super.getOfflineDefaults();
        AdCat defaults = new AdCat();
        if (mPresetFather != null)
            defaults.father = mPresetFather;
        return defaults;
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "": "admin/ad_cat/get_ad_cat.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new StringEditItem(
                new EditHeader("نام دسته‌بندی"),
                new StringContent(mDefaults.name),
                "name"
        ).asParam());


        items.add(new TextItem (
                new EditHeader("زیر‌دسته‌ی"),
                new StringContent(mDefaults.father.trim().equals("godfather")? "زیردسته‌ی دسته‌ی دیگری نیست.": mDefaults.father),
                "father"
        ).asParam());

        items.add(new AddFileItem(
                new EditHeader("آیکون"),
                new FileListContent(mType == TYPE_EDIT? new ArrayList<>(Collections.singletonList(mDefaults.icon)) : new ArrayList<>()),
                AddFileItem.FILE_TYPE_IMAGE,
                "icon"
        ));

        if (mType == TYPE_EDIT)
            items.add(new UrlSubmitItem<>(
                    BooleanOutput.class,
                    "admin/ad_cat/remove_ad_cat.php",
                    "remove"
            ).text("حذف").addParam("id", String.valueOf(mDefaults.id)));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/ad_cat/add_edit_ad_cat.php",
                mType == TYPE_EDIT? "edit": "add"
        ).text(mType == TYPE_EDIT? "ویرایش": "تایید").addParam("id", String.valueOf(mDefaults.id)));
        return items;
    }
}
