package ir.rafsanjan.admin.edit.activities.loaders;

import android.app.Activity;

import java.io.Serializable;
import java.util.ArrayList;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.Peste;
import ir.rafsanjan.admin.edit.contents.MapContent;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.MapItem;
import ir.rafsanjan.admin.edit.items.StringEditItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;

public class PesteActivityLoader extends EditActivityLoader<Peste> implements Serializable {

    public PesteActivityLoader(int requestCode) {
        super(Peste.class, requestCode);
    }

    public PesteActivityLoader() {
        super(Peste.class);
    }

    public void startActivity(Activity activity) {
        super.startActivity(activity, -1);
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return "admin/peste/get_peste.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        items.add(new MapItem(
                new EditHeader("قیمت پسته‌ها"),
                new MapContent(mDefaults.peste),
                "peste"
        ));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/peste/edit_peste.php",
                "submit"
        ));
        return items;
    }
}
