package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.AdCat;
import ir.rafsanjan.admin.edit.activities.models.Advertisement;
import ir.rafsanjan.admin.edit.activities.models.AdvertisementFilter;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.ImageItem;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;
import ir.rafsanjan.admin.utils.Utils;

public class AdvertisementActivityLoader extends EditActivityLoader<Advertisement> implements Serializable {
    public AdvertisementActivityLoader(int requestCode) {
        super(Advertisement.class, requestCode);
    }

    public AdvertisementActivityLoader() {
        super(Advertisement.class);
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "admin/advertisement/get_first_pending_advertisement.php": "admin/advertisement/get_advertisement.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new TextItem (
                new EditHeader("تیتر"),
                new StringContent(mDefaults.title),
                "title"
        ));

        items.add(new TextItem (
                new EditHeader("وضعیت"),
                new StringContent(mDefaults.status),
                "status"
        ));

        items.add(new TextItem (
                new EditHeader("متن"),
                new StringContent(mDefaults.text),
                "text"
        ));

        items.add(new TextItem (
                new EditHeader("زمان"),
                new StringContent(Utils.convertTimeToRelative(System.currentTimeMillis() / 1000, mDefaults.time)),
                "time"
        ));

        for (int i = 0; i < mDefaults.filters.size(); i++) {
            AdvertisementFilter filter = mDefaults.filters.get(i);
            items.add(new TextItem (
                    new EditHeader(filter.name),
                    new StringContent(filter.value),
                    "filter"
            ));
        }

        items.add(new TextItem (
                new EditHeader("شهر"),
                new StringContent(mDefaults.city),
                "city"
        ));

        items.add(new TextItem (
                new EditHeader("ایمیل"),
                new StringContent(mDefaults.email),
                "email"
        ));

        items.add(new TextItem (
                new EditHeader("شماره تماس"),
                new StringContent(mDefaults.phone_number),
                "phone_number"
        ));

        items.add(new TextItem (
                new EditHeader("دسته‌بندی"),
                new StringContent(mDefaults.category.name),
                "category"
        ));

        items.add(new TextItem (
                new EditHeader("زیر دسته‌بندی"),
                new StringContent(mDefaults.sub_category.name),
                "sub_category"
        ));

        items.add(new TextItem (
                new EditHeader("زیر زیر دسته‌بندی"),
                new StringContent(mDefaults.sub_sub_category.name),
                "sub_sub_category"
        ));

        for (int i = 0; i < mDefaults.images.size(); i++) {
            String image = mDefaults.images.get(i);
            items.add(new ImageItem(
                    new EditHeader(Utils.replaceDigitsWithPersian("تصویر " + (i + 1))),
                    new StringContent(image),
                    "image" + i
            ));
        }

        items.add(new TextItem (
                new EditHeader("پین"),
                new StringContent(String.valueOf(mDefaults.pin)),
                "pin"
        ));

        items.add(new UrlSubmitItem<> (
                BooleanOutput.class,
                "admin/advertisement/confirm_advertisement.php",
                "confirm"
        ).addParam("id", String.valueOf(mDefaults.id)).addParam("confirm", "1"));

        items.add(new UrlSubmitItem<> (
                BooleanOutput.class,
                "admin/advertisement/confirm_advertisement.php",
                "discard"
        ).text("عدم تایید").addParam("id", String.valueOf(mDefaults.id)).addParam("confirm", "2"));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/advertisement/pin_advertisement.php",
                "edit"
        ).text(mDefaults.pin > 0? "خارج کردن از پین": "پین کردن")
                .addParam("id", String.valueOf(mDefaults.id))
                .addParam("pinned", mDefaults.pin > 0? "0": "1")
                .addParam("confirm", mDefaults.status.contains("انتظار")? "0": mDefaults.status.contains("رد شده")? "2": "1"));

        return items;
    }
}
