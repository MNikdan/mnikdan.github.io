package ir.rafsanjan.admin.edit.activities.loaders.base;

import android.app.Activity;
import android.content.Intent;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.Nullable;
import ir.rafsanjan.admin.AdminApplication;
import ir.rafsanjan.admin.base.EditItemContainer;
import ir.rafsanjan.admin.edit.EditActivity;
import ir.rafsanjan.admin.edit.items.base.EditItem;

import static android.app.Activity.RESULT_OK;
import static ir.rafsanjan.admin.list.loaders.base.ListLoader.LIST_ITEM_REQUEST_CODE;

public abstract class EditActivityLoader<T extends Serializable> implements EditItemContainer, Serializable {
    public static final int TYPE_EDIT = 0;
    public static final int TYPE_ADD = 1;
    public static final int TYPE_LONG_ADD = 2;

    protected int mId = -1; // -1 means get the first pending one, 0 means add
    protected T mDefaults;
    private String mTClass;
    private int mRequestCode;
    protected int mType = TYPE_EDIT;

    public EditActivityLoader(Class<T> tClass, int requestCode) {
        mTClass = tClass.getSimpleName();
        mRequestCode = requestCode;
    }

    public EditActivityLoader(Class<T> tClass) {
        this(tClass, LIST_ITEM_REQUEST_CODE);
    }

    public EditActivityLoader type(int type) {
        mType = type;
        return this;
    }

    public T getTFromJson(String json) {
        try {
            return new Gson().fromJson(
                    json,
                    (Type) Class.forName("ir.rafsanjan.admin.edit.activities.models." + mTClass)
            );
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    protected abstract String getRequestDefaultsUrl();

    protected int getRequestMethod() {
        return Request.Method.GET;
    }

    protected Map<String, String> getRequestParams() {
        return new HashMap<>();
    }

    private Map<String, String> addPasswordToParams() {
        Map<String, String> params = getRequestParams();
        params.put("password", AdminApplication.PASSWORD);
        return params;
    }

    private String addParamsAtEndOfUrl() {
        Map<String, String> params = addPasswordToParams();
        StringBuilder url = new StringBuilder(AdminApplication.BASE_URL + getRequestDefaultsUrl());
        if (params.isEmpty())
            return url.toString();
        url.append('?');
        for (Map.Entry<String, String> param : params.entrySet()) {
            url.append(param.getKey()).append("=").append(param.getValue()).append("&");
        }
        if (mId != -1)
            url.append("id").append("=").append(mId).append("&");
        return url.toString();
    }

    protected T getOfflineDefaults() {
        return null;
    }

    public void startAddActivity(Activity activity) {
        startActivity(activity, 0);
    }

    public void startActivity(Activity activity, int id) {
        mId = id;

        mDefaults = getOfflineDefaults();
        if (mDefaults == null) {
            MaterialDialog dialog = new MaterialDialog.Builder(activity)
                    .progress(true, 100)
                    .title("در حال بارگزاری")
                    .cancelable(false)
                    .show();

            WeakReference<Activity> weakAct = new WeakReference<>(activity);
            AdminApplication.volley.add(new StringRequest(
                    getRequestMethod(),
                    getRequestMethod() == Request.Method.GET ? addParamsAtEndOfUrl() : AdminApplication.BASE_URL + getRequestDefaultsUrl(),
                    response -> {
                        try {
                            Activity act = weakAct.get();
                            if (act == null)
                                return;
                            JsonParser parser = new JsonParser();
                            JsonObject o = parser.parse(response.trim()).getAsJsonObject();
                            if (o.get("message") != null && o.get("message").toString().equals("\"finished\"")) {
                                if (dialog != null)
                                    dialog.dismiss();
                                finished(act);
                            } else {
                                mDefaults = getTFromJson(o.get("result").toString());
                                if (dialog != null)
                                    dialog.dismiss();
                                defaultsReady(act);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            if (dialog != null)
                                dialog.dismiss();
                        }
                    },
                    error -> {
                        if (dialog != null)
                            dialog.dismiss();
                    }
            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = getRequestParams();
                    params.put("password", AdminApplication.PASSWORD);
                    if (mId != -1)
                        params.put("id", String.valueOf(mId));
                    return params;
                }
            });
        } else {
            defaultsReady(activity);
        }
    }

    private void finished(Activity activity) {
        Toast.makeText(activity, "موردی یافت نشد.", Toast.LENGTH_SHORT).show();
    }

    private void defaultsReady(Activity activity) {
        Intent intent = new Intent(activity, EditActivity.class);
        intent.putExtra("defaults", mDefaults);
        intent.putExtra("items", getEditItems());
        intent.putExtra("loader", this);
        activity.startActivityForResult(intent, mRequestCode);
    }

    protected void onActivityResult(Intent data) {
        String returnedByTag = data.getStringExtra("returned by");
        if (returnedByTag != null)
            returnedBy(returnedByTag);
    }

    protected void returnedBy(String tag) {
    }

    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (resultCode == RESULT_OK && requestCode == mRequestCode && data != null)
            onActivityResult(data);
    }

    protected EditItem transformToAddMode(EditItem item) {
        return item.transformToAddMode();
    }
}
