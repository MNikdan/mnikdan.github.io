package ir.rafsanjan.admin.edit.activities.loaders;

import android.app.Activity;

import java.io.Serializable;
import java.util.ArrayList;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.Adad;
import ir.rafsanjan.admin.edit.contents.BooleanContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.OnOffItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;

public class AdadActivityLoader extends EditActivityLoader<Adad> implements Serializable {

    public AdadActivityLoader(int requestCode) {
        super(Adad.class, requestCode);
    }

    public AdadActivityLoader() {
        super(Adad.class);
    }

    public void startActivity(Activity activity) {
        super.startActivity(activity, -1);
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return "admin/adad/get_adad.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();
        items.add(new OnOffItem(
                new EditHeader("لیست اخبار"),
                new BooleanContent(mDefaults.news == 1),
                "news"
        ).asParam());

        items.add(new OnOffItem(
                new EditHeader("لیست آگهی‌ها"),
                new BooleanContent(mDefaults.advertisements == 1),
                "advertisements"
        ).asParam());

        items.add(new OnOffItem(
                new EditHeader("لیست عکاس‌خانه"),
                new BooleanContent(mDefaults.akkaskhoone == 1),
                "akkaskhoone"
        ).asParam());

        items.add(new OnOffItem(
                new EditHeader("صفحه‌ی داخلی اخبار"),
                new BooleanContent(mDefaults.inside_news == 1),
                "inside_news"
        ).asParam());

        items.add(new OnOffItem(
                new EditHeader("صفحه‌ی داخلی آگهی‌ها"),
                new BooleanContent(mDefaults.inside_advertisements == 1),
                "inside_advertisements"
        ).asParam());

        items.add(new OnOffItem(
                new EditHeader("صفحه‌ی داخلی کسب و کار"),
                new BooleanContent(mDefaults.inside_kasbokar == 1),
                "inside_kasbokar"
        ).asParam());

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/adad/edit_adad.php",
                "submit"
        ));
        return items;
    }
}
