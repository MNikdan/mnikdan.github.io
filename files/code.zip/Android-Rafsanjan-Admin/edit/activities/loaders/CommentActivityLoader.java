package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.Comment;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;
import ir.rafsanjan.admin.utils.Utils;

public class CommentActivityLoader extends EditActivityLoader<Comment> implements Serializable {
    public CommentActivityLoader(int requestCode) {
        super(Comment.class, requestCode);
    }

    public CommentActivityLoader() {
        super(Comment.class);
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "admin/comment/get_first_pending_comment.php": "admin/comment/get_comment.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new TextItem (
                new EditHeader("نام کاربر"),
                new StringContent(mDefaults.username),
                "username"
        ));

        items.add(new TextItem (
                new EditHeader("وضعیت"),
                new StringContent(mDefaults.status),
                "status"
        ));

        items.add(new TextItem (
                new EditHeader("زمان"),
                new StringContent(Utils.convertTimeToRelative(System.currentTimeMillis() / 1000, mDefaults.time)),
                "time"
        ));

        items.add(new TextItem (
                new EditHeader("متن"),
                new StringContent(mDefaults.text),
                "text"
        ));

        items.add(new UrlSubmitItem<> (
                BooleanOutput.class,
                "admin/comment/confirm_comment.php",
                "confirm"
        ).addParam("id", String.valueOf(mDefaults.id)).addParam("confirm", "1"));

        items.add(new UrlSubmitItem<> (
                BooleanOutput.class,
                "admin/comment/confirm_comment.php",
                "discard"
        ).text("عدم تایید").addParam("id", String.valueOf(mDefaults.id)).addParam("confirm", "2"));
        return items;
    }
}
