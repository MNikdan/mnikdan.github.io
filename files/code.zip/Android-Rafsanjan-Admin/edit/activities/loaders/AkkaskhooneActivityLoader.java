package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.Akkaskhoone;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.ImageItem;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;
import ir.rafsanjan.admin.utils.Utils;

public class AkkaskhooneActivityLoader extends EditActivityLoader<Akkaskhoone> implements Serializable {
    public AkkaskhooneActivityLoader(int requestCode) {
        super(Akkaskhoone.class, requestCode);
    }

    public AkkaskhooneActivityLoader() {
        super(Akkaskhoone.class);
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "admin/akkaskhoone/get_first_pending_akkaskhoone.php": "admin/akkaskhoone/get_akkaskhoone.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new TextItem (
                new EditHeader("نام کاربر"),
                new StringContent(mDefaults.username),
                "username"
        ));

        items.add(new TextItem (
                new EditHeader("وضعیت"),
                new StringContent(mDefaults.status),
                "status"
        ));

        items.add(new TextItem (
                new EditHeader("زمان"),
                new StringContent(Utils.convertTimeToRelative(System.currentTimeMillis() / 1000, mDefaults.time)),
                "time"
        ));

        items.add(new TextItem (
                new EditHeader("متن"),
                new StringContent(mDefaults.text),
                "text"
        ));

        items.add(new ImageItem(
                new EditHeader(Utils.replaceDigitsWithPersian("تصویر")),
                new StringContent(mDefaults.image),
                "image"
        ));

        items.add(new UrlSubmitItem<> (
                BooleanOutput.class,
                "admin/akkaskhoone/confirm_akkaskhoone.php",
                "confirm"
        ).addParam("id", String.valueOf(mDefaults.id)).addParam("confirm", "1"));

        items.add(new UrlSubmitItem<> (
                BooleanOutput.class,
                "admin/akkaskhoone/confirm_akkaskhoone.php",
                "discard"
        ).text("عدم تایید").addParam("id", String.valueOf(mDefaults.id)).addParam("confirm", "2"));
        return items;
    }
}
