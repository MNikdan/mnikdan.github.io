package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.NewsCat;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.StringEditItem;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;

public class NewsCatsActivityLoader extends EditActivityLoader<NewsCat> implements Serializable {
    public NewsCatsActivityLoader(int requestCode) {
        super(NewsCat.class, requestCode);
    }

    public NewsCatsActivityLoader() {
        super(NewsCat.class);
    }

    @Override
    protected NewsCat getOfflineDefaults() {
        if (mType == TYPE_EDIT)
            return super.getOfflineDefaults();
        return new NewsCat();
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "": "admin/news_cat/get_news_cat.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new StringEditItem(
                new EditHeader("نام دسته‌بندی"),
                new StringContent(mDefaults.name),
                "name"
        ).asParam());

        if (mType == TYPE_EDIT)
            items.add(new UrlSubmitItem<>(
                    BooleanOutput.class,
                    "admin/news_cat/remove_news_cat.php",
                    "remove"
            ).text("حذف").addParam("id", String.valueOf(mDefaults.id)));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/news_cat/add_edit_news_cat.php",
                mType == TYPE_EDIT? "edit": "add"
        ).text(mType == TYPE_EDIT? "ویرایش": "تایید").addParam("id", String.valueOf(mDefaults.id)));
        return items;
    }
}
