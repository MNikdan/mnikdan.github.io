package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.Kasbokar;
import ir.rafsanjan.admin.edit.contents.AddressContent;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.AddressItem;
import ir.rafsanjan.admin.edit.items.ImageItem;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;
import ir.rafsanjan.admin.utils.Utils;

public class KasbokarActivityLoader extends EditActivityLoader<Kasbokar> implements Serializable {
    public KasbokarActivityLoader(int requestCode) {
        super(Kasbokar.class, requestCode);
    }

    public KasbokarActivityLoader() {
        super(Kasbokar.class);
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "admin/kasbokar/get_first_pending_kasbokar.php": "admin/kasbokar/get_kasbokar.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new TextItem (
                new EditHeader("تیتر"),
                new StringContent(mDefaults.title),
                "title"
        ));

        items.add(new TextItem (
                new EditHeader("وضعیت"),
                new StringContent(mDefaults.status),
                "status"
        ));

        items.add(new TextItem (
                new EditHeader("توضیحات"),
                new StringContent(mDefaults.description),
                "description"
        ));

        for (int i = 0; i < mDefaults.addresses.size(); i++) {
            ArrayList<String> address = mDefaults.addresses.get(i);
            try {
                items.add(new AddressItem(
                        new EditHeader(Utils.replaceDigitsWithPersian("آدرس " + (i + 1))),
                        new AddressContent(address.get(0), address.get(1), address.get(2), address.get(3)),
                        "address"
                ));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        items.add(new ImageItem(
                new EditHeader("بنر"),
                new StringContent(mDefaults.banner.trim()),
                "banner"
        ));

        items.add(new ImageItem(
                new EditHeader("مجوز"),
                new StringContent(mDefaults.javaz.trim()),
                "javaz"
        ));

        for (int i = 0; i < mDefaults.phone_numbers.size(); i++) {
            String phone_number = mDefaults.phone_numbers.get(i);
            items.add(new TextItem(
                    new EditHeader(Utils.replaceDigitsWithPersian("شماره تلفن " + (i + 1))),
                    new StringContent(phone_number),
                    "phone_number"
            ));
        }

        for (int i = 0; i < mDefaults.cell_numbers.size(); i++) {
            String cell_number = mDefaults.cell_numbers.get(i);
            items.add(new TextItem(
                    new EditHeader(Utils.replaceDigitsWithPersian("شماره موبایل " + (i + 1))),
                    new StringContent(cell_number),
                    "cell_number"
            ));
        }

        for (int i = 0; i < mDefaults.images.size(); i++) {
            String image = mDefaults.images.get(i);
            items.add(new ImageItem(
                    new EditHeader(Utils.replaceDigitsWithPersian("تصویر " + (i + 1))),
                    new StringContent(image),
                    "image"
            ));
        }

        items.add(new TextItem (
                new EditHeader("دسته‌بندی"),
                new StringContent(mDefaults.category.name),
                "category"
        ));

        items.add(new TextItem (
                new EditHeader("زیر دسته‌بندی"),
                new StringContent(mDefaults.sub_category.name),
                "sub_category"
        ));

        items.add(new TextItem (
                new EditHeader("پین"),
                new StringContent(String.valueOf(mDefaults.pin)),
                "pin"
        ));

        items.add(new UrlSubmitItem<> (
                BooleanOutput.class,
                "admin/kasbokar/confirm_kasbokar.php",
                "confirm"
        ).addParam("id", String.valueOf(mDefaults.id)).addParam("confirm", "1"));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/kasbokar/confirm_kasbokar.php",
                "discard"
        ).text("عدم تایید").addParam("id", String.valueOf(mDefaults.id)).addParam("confirm", "2"));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/kasbokar/pin_kasbokar.php",
                "edit"
        ).text(mDefaults.pin > 0? "خارج کردن از پین": "پین کردن")
                .addParam("id", String.valueOf(mDefaults.id))
                .addParam("pinned", mDefaults.pin > 0? "0": "1")
                .addParam("confirm", mDefaults.status.contains("انتظار")? "0": mDefaults.status.contains("رد شده")? "2": "1"));

        return items;
    }
}
