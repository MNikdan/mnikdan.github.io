package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.Slider;
import ir.rafsanjan.admin.edit.contents.FileListContent;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.contents.StringListContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.AddFileItem;
import ir.rafsanjan.admin.edit.items.SpinnerItem;
import ir.rafsanjan.admin.edit.items.StringEditItem;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;

public class SlidersActivityLoader extends EditActivityLoader<Slider> implements Serializable {
    public SlidersActivityLoader(int requestCode) {
        super(Slider.class, requestCode);
    }

    public SlidersActivityLoader() {
        super(Slider.class);
    }

    @Override
    protected Slider getOfflineDefaults() {
        if (mType == TYPE_EDIT)
            return super.getOfflineDefaults();
        return new Slider();
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "": "admin/slider/get_slider.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new StringEditItem(
                new EditHeader("متن"),
                new StringContent(mDefaults.text),
                "text"
        ).asParam());

        items.add(new SpinnerItem(
                new EditHeader("هدف"),
                new StringListContent(new ArrayList<>(Collections.singletonList(mDefaults.type))),
                "هدف",
                "admin/slider/get_types.php",
                "type"
        ));

        items.add(new StringEditItem(
                new EditHeader("اطلاعات"),
                new StringContent(mDefaults.intent),
                "intent"
        ).asParam());

        items.add(new SpinnerItem(
                new EditHeader("مکان"),
                new StringListContent(new ArrayList<>(Collections.singletonList(mDefaults.location))),
                "مکان",
                "admin/slider/get_locations.php",
                "location"
        ));

        items.add(new AddFileItem(
                new EditHeader("تصویر"),
                new FileListContent(mType == TYPE_EDIT? new ArrayList<>(Collections.singletonList(mDefaults.image)) : new ArrayList<>()),
                AddFileItem.FILE_TYPE_IMAGE,
                "image"
        ));

        if (mType == TYPE_EDIT)
            items.add(new UrlSubmitItem<>(
                    BooleanOutput.class,
                    "admin/slider/remove_slider.php",
                    "remove"
            ).text("حذف").addParam("id", String.valueOf(mDefaults.id)));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/slider/add_edit_slider.php",
                mType == TYPE_EDIT? "edit": "add"
        ).text(mType == TYPE_EDIT? "ویرایش": "تایید").addParam("id", String.valueOf(mDefaults.id)));
        return items;
    }
}
