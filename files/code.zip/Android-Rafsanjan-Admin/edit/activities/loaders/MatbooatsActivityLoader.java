package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.contents.FileListContent;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.AddFileItem;
import ir.rafsanjan.admin.edit.activities.models.Matbooat;
import ir.rafsanjan.admin.edit.items.StringEditItem;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;

public class MatbooatsActivityLoader extends EditActivityLoader<Matbooat> implements Serializable {
    public MatbooatsActivityLoader(int requestCode) {
        super(Matbooat.class, requestCode);
    }

    public MatbooatsActivityLoader() {
        super(Matbooat.class);
    }

    @Override
    protected Matbooat getOfflineDefaults() {
        if (mType == TYPE_EDIT)
            return super.getOfflineDefaults();
        return new Matbooat();
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "": "admin/matbooat/get_matbooat.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new StringEditItem(
                new EditHeader("نام مطبوعات"),
                new StringContent(mDefaults.name),
                "name"
        ).asParam());

        items.add(new AddFileItem(
                new EditHeader("تصویر"),
                new FileListContent(mType == TYPE_EDIT? new ArrayList<>(Collections.singletonList(mDefaults.thumbnail)) : new ArrayList<>()),
                AddFileItem.FILE_TYPE_IMAGE,
                "thumbnail"
        ));

        items.add(new AddFileItem(
                new EditHeader("محتوا"),
                new FileListContent(mDefaults.images),
                AddFileItem.FILE_TYPE_IMAGE,
                "images"
        ).requestCode(3246).multi());

        items.add(new StringEditItem(
                new EditHeader("تاریخ"),
                new StringContent(String.valueOf(mDefaults.date)),
                "date"
        ));

        if (mType == TYPE_EDIT)
            items.add(new UrlSubmitItem<>(
                    BooleanOutput.class,
                    "admin/matbooat/remove_matbooat.php",
                    "remove"
            ).text("حذف").addParam("id", String.valueOf(mDefaults.id)));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/matbooat/add_edit_matbooat.php",
                mType == TYPE_EDIT? "edit": "add"
        ).text(mType == TYPE_EDIT? "ویرایش": "تایید").addParam("id", String.valueOf(mDefaults.id)));
        return items;
    }
}
