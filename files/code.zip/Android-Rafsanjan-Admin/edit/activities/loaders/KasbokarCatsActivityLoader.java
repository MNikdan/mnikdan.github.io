package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.AdCat;
import ir.rafsanjan.admin.edit.activities.models.KasbokarCat;
import ir.rafsanjan.admin.edit.contents.FileListContent;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.AddFileItem;
import ir.rafsanjan.admin.edit.items.ImageItem;
import ir.rafsanjan.admin.edit.items.StringEditItem;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;

public class KasbokarCatsActivityLoader extends EditActivityLoader<KasbokarCat> implements Serializable {
    public KasbokarCatsActivityLoader(int requestCode) {
        super(KasbokarCat.class, requestCode);
    }

    public KasbokarCatsActivityLoader() {
        super(KasbokarCat.class);
    }

    private String mPresetFather;
    public KasbokarCatsActivityLoader presetFather(String father) {
        mPresetFather = father;
        return this;
    }

    @Override
    protected KasbokarCat getOfflineDefaults() {
        if (mType == TYPE_EDIT)
            return super.getOfflineDefaults();
        KasbokarCat defaults = new KasbokarCat();
        if (mPresetFather != null)
            defaults.father = mPresetFather;
        return defaults;
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "": "admin/kasbokar_cat/get_kasbokar_cat.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new StringEditItem(
                new EditHeader("نام دسته‌بندی"),
                new StringContent(mDefaults.name),
                "name"
        ).asParam());


        items.add(new TextItem (
                new EditHeader("زیر‌دسته‌ی"),
                new StringContent(mDefaults.father.trim().equals("godfather")? "زیردسته‌ی دسته‌ی دیگری نیست.": mDefaults.father),
                "father"
        ).asParam());

        items.add(new AddFileItem(
                new EditHeader("آیکون"),
                new FileListContent(mType == TYPE_EDIT? new ArrayList<>(Collections.singletonList(mDefaults.icon)) : new ArrayList<>()),
                AddFileItem.FILE_TYPE_IMAGE,
                "icon"
        ));

        if (mType == TYPE_EDIT)
            items.add(new UrlSubmitItem<>(
                    BooleanOutput.class,
                    "admin/kasbokar_cat/remove_kasbokar_cat.php",
                    "remove"
            ).text("حذف").addParam("id", String.valueOf(mDefaults.id)));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/kasbokar_cat/add_edit_kasbokar_cat.php",
                mType == TYPE_EDIT? "edit": "add"
        ).text(mType == TYPE_EDIT? "ویرایش": "تایید").addParam("id", String.valueOf(mDefaults.id)));
        return items;
    }
}
