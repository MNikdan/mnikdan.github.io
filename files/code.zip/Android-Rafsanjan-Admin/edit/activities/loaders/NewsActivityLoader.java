package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.News;
import ir.rafsanjan.admin.edit.contents.FileListContent;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.contents.StringListContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.AddFileItem;
import ir.rafsanjan.admin.edit.items.SpinnerItem;
import ir.rafsanjan.admin.edit.items.StringEditItem;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;
import saman.zamani.persiandate.PersianDate;

public class NewsActivityLoader extends EditActivityLoader<News> implements Serializable {
    public NewsActivityLoader(int requestCode) {
        super(News.class, requestCode);
    }

    public NewsActivityLoader() {
        super(News.class);
    }

    @Override
    protected News getOfflineDefaults() {
        if (mType == TYPE_EDIT)
            return super.getOfflineDefaults();
        return new News();
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "": "admin/news/get_news.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new StringEditItem(
                new EditHeader("منبع"),
                new StringContent(mDefaults.source),
                "source"
        ).asParam());

        items.add(new StringEditItem(
                new EditHeader("تیتر"),
                new StringContent(mDefaults.title),
                "title"
        ).asParam());

        items.add(new StringEditItem(
                new EditHeader("لینک منبع"),
                new StringContent(mDefaults.link),
                "link"
        ).asParam());

        items.add(new StringEditItem(
                new EditHeader("توضیحات"),
                new StringContent(mDefaults.description),
                "description"
        ).asParam());

        items.add(new StringEditItem(
                new EditHeader("متن اصلی"),
                new StringContent(mDefaults.maintext),
                "maintext"
        ).asParam());

        items.add(new SpinnerItem(
                new EditHeader("مکان"),
                new StringListContent(new ArrayList<>(Collections.singletonList(mDefaults.location))),
                "مکان",
                "admin/news/get_locations.php",
                "location"
        ));

        items.add(new SpinnerItem(
                new EditHeader("دسته‌بندی‌ها"),
                new StringListContent(mDefaults.category),
                "دسته‌بندی",
                "admin/news/get_cats.php",
                "category"
        ).multi());

        items.add(new AddFileItem(
                new EditHeader("تصاویر"),
                new FileListContent(mDefaults.imgs),
                AddFileItem.FILE_TYPE_IMAGE,
                "imgs"
        ).multi());

        items.add(new AddFileItem(
                new EditHeader("ویدئو"),
                new FileListContent(mDefaults.hasVideo()? new ArrayList<>(Collections.singletonList(mDefaults.vids)): new ArrayList<>()),
                AddFileItem.FILE_TYPE_VIDEO,
                "vids"
        ).requestCode(8125));

        if (mType == TYPE_EDIT)
            items.add(new UrlSubmitItem<>(
                    BooleanOutput.class,
                    "admin/news/remove_news.php",
                    "remove"
            ).text("حذف").addParam("id", String.valueOf(mDefaults.id)));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/news/add_edit_news.php",
                mType == TYPE_EDIT? "edit": "add"
        ).text(mType == TYPE_EDIT? "ویرایش": "تایید").addPubdate().addParam("id", String.valueOf(mDefaults.id)));
        return items;
    }
}
