package ir.rafsanjan.admin.edit.activities.loaders;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import ir.rafsanjan.admin.edit.actions.base.outputs.BooleanOutput;
import ir.rafsanjan.admin.edit.activities.loaders.base.EditActivityLoader;
import ir.rafsanjan.admin.edit.activities.models.Block;
import ir.rafsanjan.admin.edit.contents.FileListContent;
import ir.rafsanjan.admin.edit.contents.StringContent;
import ir.rafsanjan.admin.edit.contents.StringListContent;
import ir.rafsanjan.admin.edit.headers.base.EditHeader;
import ir.rafsanjan.admin.edit.items.AddFileItem;
import ir.rafsanjan.admin.edit.items.SpinnerItem;
import ir.rafsanjan.admin.edit.items.StringEditItem;
import ir.rafsanjan.admin.edit.items.TextItem;
import ir.rafsanjan.admin.edit.items.UrlSubmitItem;
import ir.rafsanjan.admin.edit.items.base.EditItem;

public class BlocksActivityLoader extends EditActivityLoader<Block> implements Serializable {
    public BlocksActivityLoader(int requestCode) {
        super(Block.class, requestCode);
    }

    public BlocksActivityLoader() {
        super(Block.class);
    }

    @Override
    protected Block getOfflineDefaults() {
        if (mType == TYPE_EDIT)
            return super.getOfflineDefaults();
        return new Block();
    }

    @Override
    protected String getRequestDefaultsUrl() {
        return mId == -1? "": "admin/block/get_block.php";
    }

    @Override
    public ArrayList<EditItem> getEditItems() {
        ArrayList<EditItem> items = new ArrayList<>();

        if (mType == TYPE_EDIT)
            items.add(new TextItem(
                    new EditHeader("شناسه"),
                    new StringContent(String.valueOf(mDefaults.id)),
                    "id"
            ));

        items.add(new StringEditItem(
                new EditHeader("تیتر"),
                new StringContent(mDefaults.title),
                "title"
        ).asParam());

        items.add(new AddFileItem(
                new EditHeader("تصاویر"),
                new FileListContent(mDefaults.images),
                AddFileItem.FILE_TYPE_IMAGE,
                "images"
        ).multi());

        items.add(new SpinnerItem(
                new EditHeader("هدف"),
                new StringListContent(new ArrayList<>(Collections.singletonList(mDefaults.intent))),
                "هدف",
                "admin/block/get_intents.php",
                "intent"
        ));

        items.add(new SpinnerItem(
                new EditHeader("دسته‌بندی (در صورت وجود)"),
                new StringListContent(new ArrayList<>(Collections.singletonList(mDefaults.category))),
                "دسته‌بندی",
                "admin/block/get_categories.php",
                "category"
        ));

        items.add(new StringEditItem(
                new EditHeader("لینک (در صورت وجود)"),
                new StringContent(mDefaults.url),
                "url"
        ).asParam());

        items.add(new StringEditItem(
                new EditHeader("مکان طولی (شروع)"),
                new StringContent(String.valueOf(mDefaults.startx)),
                "startx"
        ));

        items.add(new StringEditItem(
                new EditHeader("مکان طولی (پایان)"),
                new StringContent(String.valueOf(mDefaults.endx)),
                "endx"
        ));

        items.add(new StringEditItem(
                new EditHeader("مکان عرضی (شروع)"),
                new StringContent(String.valueOf(mDefaults.starty)),
                "starty"
        ));

        items.add(new StringEditItem(
                new EditHeader("مکان عرضی (پایان)"),
                new StringContent(String.valueOf(mDefaults.endy)),
                "endy"
        ));

        if (mType == TYPE_EDIT)
            items.add(new UrlSubmitItem<>(
                    BooleanOutput.class,
                    "admin/block/remove_block.php",
                    "remove"
            ).text("حذف").addParam("id", String.valueOf(mDefaults.id)));

        items.add(new UrlSubmitItem<>(
                BooleanOutput.class,
                "admin/block/add_edit_block.php",
                mType == TYPE_EDIT? "edit": "add"
        ).text(mType == TYPE_EDIT? "ویرایش": "تایید").addParam("id", String.valueOf(mDefaults.id)));
        return items;
    }
}
