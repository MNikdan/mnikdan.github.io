package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;
import java.util.ArrayList;

import ir.rafsanjan.admin.edit.contents.base.Tuple;

public class Peste implements Serializable {
    public ArrayList<Tuple> peste = new ArrayList<>();
}
