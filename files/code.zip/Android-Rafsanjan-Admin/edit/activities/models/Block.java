package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;
import java.util.ArrayList;

public class Block implements Serializable {
    public int id, startx, endx, starty, endy;
    public String title = "", intent = "", category = "", url = "";
    public ArrayList<String> images = new ArrayList<>();
}
