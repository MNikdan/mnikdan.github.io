package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;

public class AdCat implements Serializable {
    public int id;
    public String name, father, icon = "";
}
