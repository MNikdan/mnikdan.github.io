package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;

public class User implements Serializable {
    public int id, active = 1;
    public String username = "", image = "", phone = "", pass = "";
}
