package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;

public class Akkaskhoone implements Serializable {
    public int id;
    public String username;
    public String text;
    public String image;
    public String status;
    public long time;
}
