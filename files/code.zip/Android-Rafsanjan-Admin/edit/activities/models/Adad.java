package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;

public class Adad implements Serializable {
    public int news, advertisements, inside_news, inside_advertisements, inside_kasbokar, akkaskhoone;
}
