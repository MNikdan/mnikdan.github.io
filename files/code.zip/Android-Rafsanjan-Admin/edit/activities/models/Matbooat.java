package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;
import java.util.ArrayList;

public class Matbooat implements Serializable {
    public int id;
    public String name = "", date = "", thumbnail = "";
    public ArrayList<String> images = new ArrayList<>();
}
