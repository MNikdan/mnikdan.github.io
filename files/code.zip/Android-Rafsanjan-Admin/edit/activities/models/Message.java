package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;
import java.util.ArrayList;

public class Message implements Serializable {
    public int id;
    public String title = "", description = "", text = "", data = "";
}
