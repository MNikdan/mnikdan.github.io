package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;
import java.util.ArrayList;

public class Slider implements Serializable {
    public int id;
    public String text = "", intent = "", type = "", image, location = "";
}
