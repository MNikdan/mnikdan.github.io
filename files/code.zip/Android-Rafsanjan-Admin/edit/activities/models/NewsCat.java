package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;

public class NewsCat implements Serializable {
    public int id;
    public String name;
}
