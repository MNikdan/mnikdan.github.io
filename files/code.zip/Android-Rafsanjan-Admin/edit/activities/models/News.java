package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;
import java.util.ArrayList;

public class News implements Serializable {
    public int id;
    public String source = "", title = "", link = "", description = "", maintext = "", vids = "", location = "";
    public ArrayList<String> imgs = new ArrayList<>(), category = new ArrayList<>();

    public boolean hasVideo() {
        return vids != null && !vids.replace("-", "").trim().isEmpty();
    }
}
