package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;
import java.util.ArrayList;

public class Kasbokar implements Serializable {
    public int id, pin;
    public String title, description, banner, javaz;
    public ArrayList<ArrayList<String>> addresses = new ArrayList<>();
    public ArrayList<String> phone_numbers = new ArrayList<>();
    public ArrayList<String> cell_numbers = new ArrayList<>();
    public ArrayList<String> images = new ArrayList<>();
    public Category category, sub_category;
    public String status;
}
