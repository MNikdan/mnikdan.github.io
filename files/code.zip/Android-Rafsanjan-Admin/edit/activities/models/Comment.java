package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;

public class Comment implements Serializable {
    public int id;
    public String text, username;
    public long time;
    public String status;
}
