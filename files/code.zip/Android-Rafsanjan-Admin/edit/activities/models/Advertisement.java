package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;
import java.util.ArrayList;

public class Advertisement implements Serializable {
    public int id, pin;
    public String title, phone_number, text, city, email, status;
    public ArrayList<String> images = new ArrayList<>();
    public ArrayList<AdvertisementFilter> filters = new ArrayList<>();
    public Category category, sub_category, sub_sub_category;
    public long time;
}
