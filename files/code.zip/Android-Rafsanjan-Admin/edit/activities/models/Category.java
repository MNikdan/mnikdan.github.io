package ir.rafsanjan.admin.edit.activities.models;

import java.io.Serializable;

public class Category implements Serializable {
    public int id;
    public String name;
}
