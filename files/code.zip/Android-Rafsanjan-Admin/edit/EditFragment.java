package ir.rafsanjan.admin.edit;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.base.BaseFragment;
import ir.rafsanjan.admin.edit.items.base.EditItem;

@SuppressWarnings("unchecked")
public class EditFragment extends BaseFragment {
    private ViewGroup mLayout;
    private RecyclerView mRecycler;
    private EditAdapter mAdapter;

    private List<EditItem> mItems;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        assert (args != null);
        mItems = (List<EditItem>) args.getSerializable("items");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.edit_fragment, container, false);
        init(view);
        return view;
    }

    private void init(View view) {
        mLayout = (ViewGroup) view;
        mRecycler = view.findViewById(R.id.edit_fragment_recycler);
        mRecycler.setLayoutManager(new LinearLayoutManager(view.getContext()));

        mAdapter = new EditAdapter(mItems);
        mRecycler.setAdapter(mAdapter);
    }

    public static EditFragment newInstance(Bundle args) {
        EditFragment fragment = new EditFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (mAdapter != null)
            mAdapter.onActivityResult(requestCode, resultCode, data);
    }
}
