package ir.rafsanjan.admin.edit.headers.base;

import java.io.Serializable;

public class EditHeader implements Serializable {
    public String header;

    public EditHeader(String header) {
        this.header = header;
    }
}
