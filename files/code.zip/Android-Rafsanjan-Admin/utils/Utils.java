package ir.rafsanjan.admin.utils;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import androidx.annotation.RequiresApi;
import ir.rafsanjan.admin.AdminApplication;
import saman.zamani.persiandate.PersianDate;

public class Utils {
    private static List<Character> persianDigits = new ArrayList<>();
    private static List<Character> englishDigits = new ArrayList<>();
    private static List<Character> arabicDigits = new ArrayList<>();

    static {
        englishDigits.add('0');
        englishDigits.add('1');
        englishDigits.add('2');
        englishDigits.add('3');
        englishDigits.add('4');
        englishDigits.add('5');
        englishDigits.add('6');
        englishDigits.add('7');
        englishDigits.add('8');
        englishDigits.add('9');

        persianDigits.add('۰');
        persianDigits.add('١');
        persianDigits.add('۲');
        persianDigits.add('۳');
        persianDigits.add('۴');
        persianDigits.add('۵');
        persianDigits.add('۶');
        persianDigits.add('۷');
        persianDigits.add('۸');
        persianDigits.add('۹');

        arabicDigits.add('٠');
        arabicDigits.add('١');
        arabicDigits.add('٢');
        arabicDigits.add('٣');
        arabicDigits.add('٤');
        arabicDigits.add('٥');
        arabicDigits.add('٦');
        arabicDigits.add('٧');
        arabicDigits.add('٨');
        arabicDigits.add('٩');
    }

    public static String replaceDigitsWithPersian(String str) {
        if (str == null)
            return null;
        String res = str + "";
        for (int i = 0; i < 10; i++) {
            res = res.replace(englishDigits.get(i), persianDigits.get(i));
            res = res.replace(arabicDigits.get(i), persianDigits.get(i));
        }
        return res;
    }

    public static String convertTimeToRelative(long currentTime, long time) {
        long seconds = currentTime - time;

        long minutes = seconds / 60;
        if (minutes < 15)
            return "دقایقی قبل";
        else if (minutes < 30)
            return "یک ربع قبل";
        else if (minutes < 60)
            return "نیم ساعت قبل";

        long hours = minutes / 60;
        if (hours < 24)
            return hours + " ساعت قبل";

        long days = hours / 24;
        if (days == 1)
            return "دیروز";
        else if (days == 2)
            return "پریروز";
        if (days < 7)
            return days + " روز قبل";

        long weeks = days / 7;
        if (weeks < 4)
            return weeks + " هفته قبل";

        long month = weeks / 4;
        return month + " ماه قبل";
    }

    public static int dpToPx(float dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, Resources.getSystem().getDisplayMetrics());
    }

    public static void setTopMargin(View view, int t) {
        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        if (params.topMargin != t) {
            params.topMargin = t;
            view.setLayoutParams(params);
        }
    }

    public static void setLeftMargin(View view, int l) {
        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        if (params.leftMargin != l) {
            params.leftMargin = l;
            view.setLayoutParams(params);
        }
    }

    public static void setRightMargin(View view, int r) {
        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        if (params.rightMargin != r) {
            params.rightMargin = r;
            view.setLayoutParams(params);
        }
    }

    public static void setBottomMargin(View view, int b) {
        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        if (params.bottomMargin != b) {
            params.bottomMargin = b;
            view.setLayoutParams(params);
        }
    }

    public static void setMargins(View view, int l, int t, int r, int b) {
        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) view.getLayoutParams();

        if (params.leftMargin == l && params.topMargin == t && params.rightMargin == r && params.bottomMargin == b)
            return;

        params.leftMargin = l;
        params.topMargin = t;
        params.rightMargin = r;
        params.bottomMargin = b;

        view.setLayoutParams(params);
    }

    public static boolean isInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static void copy(File src, File dst) throws IOException {
        InputStream in = new FileInputStream(src);
        try {
            OutputStream out = new FileOutputStream(dst);
            try {
                // Transfer bytes from in to out
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
            } finally {
                out.close();
            }
        } finally {
            in.close();
        }
    }

    private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    public static String random(int len) {
        StringBuilder builder = new StringBuilder();
        while (len-- != 0) {
            int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
            builder.append(ALPHA_NUMERIC_STRING.charAt(character));
        }
        return builder.toString();
    }

    private static String randomString(String prefix) {
        return prefix + "_" + System.currentTimeMillis() + "_" + random(10);
    }

    public static String getFilesPath(){
        File f = new File(Environment.getExternalStorageDirectory(), "RafsanjanAdmin");
        if (!f.exists()) {
            f.mkdirs();
        }
        return f.getAbsolutePath();
    }

    public static File copyFileToUniqueFileName(File src) throws IOException {
        File dst = new File(getFilesPath() + "/" + randomString("copy") + ".jpg");
        copy(src, dst);
        return dst;
    }

    /* Get uri related content real local file path. */
    public static String getUriRealPath(Uri uri) {
        Context ctx = AdminApplication.app;
        String ret = "";

        if (isAboveKitKat()) {
            // Android OS above sdk version 19.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                ret = getUriRealPathAboveKitkat(ctx, uri);
            }
        } else {
            // Android OS below sdk version 19
            ret = getImageRealPath(ctx.getContentResolver(), uri, null);
        }

        return ret;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private static String getUriRealPathAboveKitkat(Context ctx, Uri uri) {
        String ret = "";

        if (ctx != null && uri != null) {

            if (isContentUri(uri)) {
                if (isGooglePhotoDoc(uri.getAuthority())) {
                    ret = uri.getLastPathSegment();
                } else {
                    ret = getImageRealPath(ctx.getContentResolver(), uri, null);
                }
            } else if (isFileUri(uri)) {
                ret = uri.getPath();
            } else if (isDocumentUri(ctx, uri)) {

                // Get uri related document id.
                String documentId = DocumentsContract.getDocumentId(uri);

                // Get uri authority.
                String uriAuthority = uri.getAuthority();

                if (isMediaDoc(uriAuthority)) {
                    String[] idArr = documentId.split(":");
                    if (idArr.length == 2) {
                        // First item is document type.
                        String docType = idArr[0];

                        // Second item is document real id.
                        String realDocId = idArr[1];

                        // Get content uri by document type.
                        Uri mediaContentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                        if ("image".equals(docType)) {
                            mediaContentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                        } else if ("video".equals(docType)) {
                            mediaContentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                        } else if ("audio".equals(docType)) {
                            mediaContentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                        }

                        // Get where clause with real document id.
                        String whereClause = MediaStore.Images.Media._ID + " = " + realDocId;

                        ret = getImageRealPath(ctx.getContentResolver(), mediaContentUri, whereClause);
                    }

                } else if (isDownloadDoc(uriAuthority)) {
                    // Build download uri.
                    Uri downloadUri = Uri.parse("content://downloads/public_downloads");

                    // Append download document id at uri end.
                    Uri downloadUriAppendId = ContentUris.withAppendedId(downloadUri, Long.valueOf(documentId));

                    ret = getImageRealPath(ctx.getContentResolver(), downloadUriAppendId, null);

                } else if (isExternalStoreDoc(uriAuthority)) {
                    String[] idArr = documentId.split(":");
                    if (idArr.length == 2) {
                        String type = idArr[0];
                        String realDocId = idArr[1];

                        if ("primary".equalsIgnoreCase(type)) {
                            ret = Environment.getExternalStorageDirectory() + "/" + realDocId;
                        }
                    }
                }
            }
        }

        return ret;
    }

    /* Check whether current android os version is bigger than kitkat or not. */
    private static boolean isAboveKitKat() {
        boolean ret = false;
        ret = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;
        return ret;
    }

    /* Check whether this uri represent a document or not. */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private static boolean isDocumentUri(Context ctx, Uri uri) {
        boolean ret = false;
        if (ctx != null && uri != null) {
            ret = DocumentsContract.isDocumentUri(ctx, uri);
        }
        return ret;
    }

    /* Check whether this uri is a content uri or not.
     *  content uri like content://media/external/images/media/1302716
     *  */
    private static boolean isContentUri(Uri uri) {
        boolean ret = false;
        if (uri != null) {
            String uriSchema = uri.getScheme();
            if ("content".equalsIgnoreCase(uriSchema)) {
                ret = true;
            }
        }
        return ret;
    }

    /* Check whether this uri is a file uri or not.
     *  file uri like file:///storage/41B7-12F1/DCIM/Camera/IMG_20180211_095139.jpg
     * */
    private static boolean isFileUri(Uri uri) {
        boolean ret = false;
        if (uri != null) {
            String uriSchema = uri.getScheme();
            if ("file".equalsIgnoreCase(uriSchema)) {
                ret = true;
            }
        }
        return ret;
    }


    /* Check whether this document is provided by ExternalStorageProvider. */
    private static boolean isExternalStoreDoc(String uriAuthority) {
        boolean ret = false;

        if ("com.android.externalstorage.documents".equals(uriAuthority)) {
            ret = true;
        }

        return ret;
    }

    /* Check whether this document is provided by DownloadsProvider. */
    private static boolean isDownloadDoc(String uriAuthority) {
        boolean ret = false;

        if ("com.android.providers.downloads.documents".equals(uriAuthority)) {
            ret = true;
        }

        return ret;
    }

    /* Check whether this document is provided by MediaProvider. */
    private static boolean isMediaDoc(String uriAuthority) {
        boolean ret = false;

        if ("com.android.providers.media.documents".equals(uriAuthority)) {
            ret = true;
        }

        return ret;
    }

    /* Check whether this document is provided by google photos. */
    private static boolean isGooglePhotoDoc(String uriAuthority) {
        boolean ret = false;

        if ("com.google.android.apps.photos.content".equals(uriAuthority)) {
            ret = true;
        }

        return ret;
    }

    /* Return uri represented document file real local path.*/
    private static String getImageRealPath(ContentResolver contentResolver, Uri uri, String whereClause) {
        String ret = "";

        // Query the uri with condition.
        Cursor cursor = contentResolver.query(uri, null, whereClause, null, null);

        if (cursor != null) {
            boolean moveToFirst = cursor.moveToFirst();
            if (moveToFirst) {

                // Get columns name by uri type.
                String columnName = MediaStore.Images.Media.DATA;

                if (uri == MediaStore.Images.Media.EXTERNAL_CONTENT_URI) {
                    columnName = MediaStore.Images.Media.DATA;
                } else if (uri == MediaStore.Audio.Media.EXTERNAL_CONTENT_URI) {
                    columnName = MediaStore.Audio.Media.DATA;
                } else if (uri == MediaStore.Video.Media.EXTERNAL_CONTENT_URI) {
                    columnName = MediaStore.Video.Media.DATA;
                }

                // Get column index.
                int imageColumnIndex = cursor.getColumnIndex(columnName);

                // Get column value which is the uri related file local path.
                ret = cursor.getString(imageColumnIndex);
            }
        }

        return ret;
    }

    public static String getSaltString(int len) {
        String saltChars = "abcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < len) {
            int index = (int) (rnd.nextFloat() * saltChars.length());
            salt.append(saltChars.charAt(index));
        }
        return salt.toString();
    }

    public static String generateRandomString(String prefix) {
        return prefix + "_" + System.currentTimeMillis() + "_" + getSaltString(10);
    }

    public static double getImageRatio(File imageFile) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imageFile.getAbsolutePath(), options);
        int imageHeight = options.outHeight;
        int imageWidth = options.outWidth;

        return (double) imageHeight / imageWidth;
    }

    public static String hourAndMinuteToString(int h, int m) {
        String hour = String.valueOf(h);
        if (hour.length() < 2)
            hour = "0" + hour;
        String minute = String.valueOf(m);
        if (minute.length() < 2)
            minute = "0" + minute;

        return Utils.replaceDigitsWithPersian(hour + ":" + minute);
    }

    public static String monthAndDay(long time) {
        PersianDate persianDate = new PersianDate(time * 1000);
        return Utils.replaceDigitsWithPersian(persianDate.getShDay() + " " + persianDate.monthName());
    }

    public static void setViewWidth(View view, int width) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        if (params == null)
            params = new ViewGroup.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        else
            params.width = width;
        view.setLayoutParams(params);
    }

    public static void resizeView(View view, int w, int h) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        if (params == null)
            params = new ViewGroup.LayoutParams(w, h);
        else {
            params.width = w;
            params.height = h;
        }
        view.setLayoutParams(params);
    }

    public static String hourAndMinuteFromDate(PersianDate persianDate) {
        return hourAndMinuteToString(persianDate.getHour(), persianDate.getMinute());
    }

    public static String hourAndMinuteFromDate(long time) {
        return hourAndMinuteFromDate(new PersianDate(time * 1000));
    }

    public static String timeForChatList(long time) {
        PersianDate persianDate = new PersianDate(time * 1000);

        PersianDate now = new PersianDate(System.currentTimeMillis());
        PersianDate endOfDay = now.endOfDay();
        long startOfDay = endOfDay.getTime() / 1000 - 86400L;

        if (time > startOfDay)
            return hourAndMinuteFromDate(persianDate);
        else
            return persianDate.dayName();
    }

    public static String getRealPathFromURI_API19(Context context, Uri uri){
        String filePath = "";
        String wholeID = DocumentsContract.getDocumentId(uri);

        String id = wholeID.split(":")[1];

        String[] column = { MediaStore.Images.Media.DATA };

        // where id is equal to
        String sel = MediaStore.Images.Media._ID + "=?";

        Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                column, sel, new String[]{ id }, null);

        int columnIndex = cursor.getColumnIndex(column[0]);

        if (cursor.moveToFirst()) {
            filePath = cursor.getString(columnIndex);
        }
        cursor.close();
        return filePath;
    }
}
