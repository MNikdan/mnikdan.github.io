package ir.rafsanjan.admin.utils;

import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import ir.rafsanjan.admin.AdminApplication;
import ir.rafsanjan.admin.R;

public abstract class InfiniteAdapter<E> extends RecyclerView.Adapter {
    private static final int TYPE_PB = 9992;

    private RecyclerView mRecyclerView;
    private int downloadOffset;
    private boolean downloading = false, allItemsDownloaded = false;
    private int lastItemMargin = 0;
    private int pbMargin = Utils.dpToPx(10);
    private boolean reverseLayout = false;
    protected boolean isInitiallyEmpty = false;
    private DownloadTask<E> downloadTask;

    public InfiniteAdapter(int downloadOffset){
        this.downloadOffset = downloadOffset;
    }

    public InfiniteAdapter(int downloadOffset, int pbMargin){
        this(downloadOffset);
        this.pbMargin = pbMargin;
    }

    public void setAsIsInitialEmpty() {
        isInitiallyEmpty = true;
    }

    public void setReverseLayout(boolean reverseLayout) {
        this.reverseLayout = reverseLayout;
    }

    public void dataSetChanged() {
        resetDownloads();
        if((!isInitiallyEmpty || getMainItems().size() != 0) && getMainItems().size() < getEveryDownloadItemCount())
            allItemsDownloaded = true;
    }

    @Override
    public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        mRecyclerView = recyclerView;
    }

    public abstract List<E> downloadNewItems();

    public abstract void addItems(List<E> newItems);
    public abstract void bind(RecyclerView.ViewHolder holder, int position);
    public abstract RecyclerView.ViewHolder create(ViewGroup parent, int viewType);
    public abstract int getType(int position);
    public abstract int getCount();
    public abstract int getEveryDownloadItemCount();
    public abstract List<E> getMainItems();

    protected void resetDownloads() {
        if(downloadTask != null)
            downloadTask.cancel(true);
        allItemsDownloaded = false;
        downloading = false;
    }

    public void onDownloaded(List<E> newItems){
        if(newItems != null) {
            if(newItems.size() < getEveryDownloadItemCount())
                allItemsDownloaded = true;
            int previousMainContentCount = getCount();
            addItems(newItems);
            notifyNewItems(previousMainContentCount);
            downloading = false;
        } else if (!downloading){
            executeDownloadTask();
        }
    }

    private void notifyNewItems(int mainItemsPreviousSize) {
        int mainItemsNewSize = getCount();
        for (int i = mainItemsPreviousSize; i < mainItemsNewSize; i++) {
            notifyItemInserted(i);
        }
        try {
            if (allItemsDownloaded)
                notifyItemRemoved(mainItemsNewSize);
            if (mainItemsPreviousSize == 0 && isInitiallyEmpty && mRecyclerView != null)
                mRecyclerView.scrollToPosition(0);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        int itemCount = getCount();
        if (isInitiallyEmpty && !allItemsDownloaded && !downloading && itemCount == 0) {
            executeDownloadTask();
        }
        return itemCount + (allItemsDownloaded? 0: 1);
    }

    @Override
    public int getItemViewType(int position) {
        if(!allItemsDownloaded && position == getItemCount() - 1)
            return TYPE_PB;
        else
            return getType(position);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int type) {
        if(type == TYPE_PB) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.infinite_pb_layout, parent, false);
            return new PBHolder(view);
        }
        return create(parent, type);
    }

    private static final int ANIMATION_DURATION = 400;
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        try {
            if (!allItemsDownloaded && getCount() > 0 && !downloading && position > getItemCount() - downloadOffset) {
                executeDownloadTask();
            }

            if (allItemsDownloaded || position != getItemCount() - 1) {
                bind(holder, position);
                if (position == getItemCount() - 2) {
                    if (reverseLayout) {
                        lastItemMargin = ((ViewGroup.MarginLayoutParams) holder.itemView.getLayoutParams()).topMargin;
                    } else {
                        lastItemMargin = ((ViewGroup.MarginLayoutParams) holder.itemView.getLayoutParams()).bottomMargin;
                    }
                }
            } else {
                if (reverseLayout) {
                    Utils.setBottomMargin(holder.itemView, pbMargin - lastItemMargin);
                } else {
                    Utils.setTopMargin(holder.itemView, pbMargin - lastItemMargin);
                }
                holder.itemView.setVisibility(View.INVISIBLE);
                AdminApplication.handler.post(() -> {
                    try {
                        YoYo.with(Techniques.Landing)
                                .repeat(0)
                                .duration(ANIMATION_DURATION)
                                .onStart((animator) -> holder.itemView.setVisibility(View.VISIBLE))
                                .playOn(holder.itemView);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private void executeDownloadTask() {
        if (downloading)
            return;
        downloading = true;
        OnPostExecuteGettingList<E> onPostExecute = this::onDownloaded;
        this.downloadTask = new DownloadTask<>(this::downloadNewItems, onPostExecute);
        this.downloadTask.execute();
    }

    private class PBHolder extends RecyclerView.ViewHolder {
        private ViewGroup layout;
        private View pb;

        public PBHolder(@NonNull View itemView) {
            super(itemView);

            layout = itemView.findViewById(R.id.infinite_pb_layout);
            pb = itemView.findViewById(R.id.infinite_pb_pb);

            Utils.setMargins(layout, 0, pbMargin, 0, pbMargin);
        }
    }

    private interface DoInBackReturningList<H> {
        List<H> doInBackground();
    }

    private interface OnPostExecuteGettingList<H> {
        void onPostExecute(List<H> newItems);
    }

    private static class DownloadTask<T> extends AsyncTask<Object, Boolean, List<T>> {
        private OnPostExecuteGettingList<T> onPostExecute;
        private DoInBackReturningList<T> doInBackground;

        public DownloadTask(DoInBackReturningList<T> doInBackground, OnPostExecuteGettingList<T> onPostExecute) {
            this.doInBackground = doInBackground;
            this.onPostExecute = onPostExecute;
        }

        @Override
        protected List<T> doInBackground(Object... objects) {
            try {
                return doInBackground.doInBackground();
            } catch (Exception e){
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(List<T> newItems) {
            try {
                onPostExecute.onPostExecute(newItems);
            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
