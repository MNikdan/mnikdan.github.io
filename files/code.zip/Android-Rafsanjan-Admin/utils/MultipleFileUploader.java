package ir.rafsanjan.admin.utils;

import android.os.Looper;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.SyncHttpClient;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cz.msebera.android.httpclient.Header;

import static ir.rafsanjan.admin.AdminApplication.DOWNLOAD_SERVER;

public class MultipleFileUploader {
    public interface MultiUploadListener{
        void onSuccess(Map<String, String> urls, String tag);

        void onFailure(String tag);
    }

    private List<String> mFiles = new ArrayList<>();
    private Map<String, String> mUrls = new HashMap<>();
    private String mTag;
    private boolean mAlreadyExecuted = false;
    private int mFinalUrlsSize = 0;

    public MultipleFileUploader(String tag) {
        mTag = tag;
    }

    public void addFiles(List<String> files) {
        mFiles.addAll(files);
    }

    public boolean isEmpty() {
        return mFiles.isEmpty();
    }

    public void execute(MultiUploadListener listener) {
        mFinalUrlsSize = mFiles.size();
        handleAlreadyUploadedOnes();

        if (mAlreadyExecuted)
            return;
        mAlreadyExecuted = true;

        if (isEmpty()) {
            listener.onSuccess(mUrls, mTag);
            return;
        }

        Looper.prepare();
        for (String path: mFiles) {
            File file = new File(path);
            File copy;
            try {
                copy = Utils.copyFileToUniqueFileName(file);
            } catch (IOException e) {
                e.printStackTrace();
                listener.onFailure(mTag);
                return;
            }

            RequestParams params = new RequestParams();
            try {
                params.put("file", copy);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            SyncHttpClient client = new SyncHttpClient();
            client.setTimeout(20 * 1000);
            client.post(DOWNLOAD_SERVER + "upload.php", params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                    String response = new String(responseBody);
                    if (response.contains("failed")) {
                        copy.deleteOnExit();
                        listener.onFailure(mTag);
                        return;
                    }

                    mUrls.put(path, DOWNLOAD_SERVER + "uploads/" + copy.getName());
                    copy.deleteOnExit();

                    if (mUrls.size() == mFinalUrlsSize)
                        listener.onSuccess(mUrls, mTag);
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    copy.deleteOnExit();
                    listener.onFailure(mTag);
                }
            });
        }
    }

    private void handleAlreadyUploadedOnes() {
        List<String> newFiles = new ArrayList<>();
        for (String file: mFiles) {
            if (file.startsWith("http"))
                mUrls.put(file, file);
            else
                newFiles.add(file);
        }
        mFiles = newFiles;
    }
}
