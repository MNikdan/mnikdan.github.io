package ir.rafsanjan.admin.utils;

import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.Nullable;
import ir.rafsanjan.admin.R;
import ir.rafsanjan.admin.base.BaseActivity;

import com.bumptech.glide.Glide;
import com.github.chrisbanes.photoview.PhotoView;

public class FullSizeImageActivity extends BaseActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.full_size_image_activity);

        PhotoView image = findViewById(R.id.full_size_image);
        Uri uri = getIntent().getParcelableExtra("uri");
        Glide.with(this).load(uri).into(image);
    }
}
