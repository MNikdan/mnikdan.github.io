Mahdi Nikdan

This folder contains some sample codes implemented by me.

IEEE-Paper: I have implemented almost all of the codes in my IEEE journal paper. But since the codes are not published yet, I could not share the whole project. However, I have put a small portion of a baseline code, which is implemented by me.

IEEE-Regression-HandsOn: This is the full regression hands-on mentioned in my CV. Everything before "Polynomial Models" section is implemented by me (around first 70 percents).

Android-Rafsanjan-Admin: Contains some parts of the client side java code for an android application. This is the admin app for the "Rafsanjan Application" mentioned in my CV.

Modern-Information-Retrieval: The project of the course Modern Information Retrieval by Prof. Mahdieh Soleymani at Sharif University of Technology. In this file, some simple ML methods are implemented by me. For instance, KNN, KMeans, Naive Bayes Classification, etc.